import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Progress } from '../../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { 
  Users, 
  Clock, 
  Activity, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  User,
  Calendar
} from 'lucide-react';
import { 
  QueueEntry,
  DoctorQueueStats,
  getAllQueueEntries, 
  getDoctorStats, 
  getTotalWaitingPatients,
  getActiveDoctorsCount,
  getLongestQueue
} from './QueueManager';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export const SmartQueueDashboard: React.FC = () => {
  const [queueEntries, setQueueEntries] = useState<QueueEntry[]>([]);
  const [doctorStats, setDoctorStats] = useState<DoctorQueueStats[]>([]);
  const [totalWaiting, setTotalWaiting] = useState(0);
  const [activeDoctors, setActiveDoctors] = useState(0);
  const [longestQueue, setLongestQueue] = useState<{ doctorName: string; count: number } | null>(null);

  const loadDashboardData = () => {
    const entries = getAllQueueEntries();
    const stats = getDoctorStats();
    const waiting = getTotalWaitingPatients();
    const active = getActiveDoctorsCount();
    const longest = getLongestQueue();

    setQueueEntries(entries);
    setDoctorStats(stats);
    setTotalWaiting(waiting);
    setActiveDoctors(active);
    setLongestQueue(longest);
  };

  useEffect(() => {
    loadDashboardData();
    // Refresh every 30 seconds
    const interval = setInterval(loadDashboardData, 30000);
    return () => clearInterval(interval);
  }, []);

  // Prepare data for charts
  const doctorQueueData = doctorStats.map(stat => ({
    name: stat.doctorName.replace('Dr. ', ''),
    waiting: queueEntries.filter(e => e.doctorId === stat.doctorId && e.status === 'waiting').length,
    inProgress: queueEntries.filter(e => e.doctorId === stat.doctorId && e.status === 'in-progress').length,
    completed: stat.completedToday
  }));

  const urgencyData = [
    { 
      name: 'Normal', 
      value: queueEntries.filter(e => e.urgency === 'normal' && e.status === 'waiting').length,
      color: '#4CAF50'
    },
    { 
      name: 'Urgent', 
      value: queueEntries.filter(e => e.urgency === 'urgent' && e.status === 'waiting').length,
      color: '#FF9800'
    },
    { 
      name: 'Emergency', 
      value: queueEntries.filter(e => e.urgency === 'emergency' && e.status === 'waiting').length,
      color: '#F44336'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-progress': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'completed': return 'bg-green-100 text-green-800 border-green-300';
      case 'cancelled': return 'bg-gray-100 text-gray-800 border-gray-300';
      default: return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'emergency': return 'bg-red-100 text-red-800 border-red-300';
      case 'urgent': return 'bg-orange-100 text-orange-800 border-orange-300';
      default: return 'bg-green-100 text-green-800 border-green-300';
    }
  };

  const totalCompleted = doctorStats.reduce((sum, stat) => sum + stat.completedToday, 0);
  const totalInProgress = queueEntries.filter(e => e.status === 'in-progress').length;
  const averageQueueSize = doctorStats.length > 0 
    ? (totalWaiting / doctorStats.length).toFixed(1)
    : '0';

  return (
    <div className="min-h-screen bg-[#FAFAF5] p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-[#2C3E2C]">Smart Queue Dashboard</h1>
          <p className="text-gray-600">Real-time overview of all consultation queues</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-[#4CAF50] bg-white shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardDescription>Total Waiting</CardDescription>
                <Users className="h-5 w-5 text-[#4CAF50]" />
              </div>
              <CardTitle className="text-[#4CAF50]">{totalWaiting}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600">
                Patients in queue
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-300 bg-white shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardDescription>Active Doctors</CardDescription>
                <Activity className="h-5 w-5 text-blue-600" />
              </div>
              <CardTitle className="text-blue-600">{activeDoctors}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600">
                Currently consulting
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-300 bg-white shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardDescription>Completed Today</CardDescription>
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <CardTitle className="text-green-600">{totalCompleted}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600">
                Total consultations
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#C19A4A] bg-white shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardDescription>Avg Queue Size</CardDescription>
                <TrendingUp className="h-5 w-5 text-[#C19A4A]" />
              </div>
              <CardTitle className="text-[#C19A4A]">{averageQueueSize}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600">
                Per doctor
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Longest Queue Alert */}
        {longestQueue && longestQueue.count > 0 && (
          <Card className="border-orange-300 bg-orange-50">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-orange-600 mt-0.5" />
                <div>
                  <p className="text-orange-900">
                    <strong>{longestQueue.doctorName}</strong> has the longest queue with{' '}
                    <strong>{longestQueue.count}</strong> {longestQueue.count === 1 ? 'patient' : 'patients'} waiting.
                  </p>
                  <p className="text-sm text-orange-800 mt-1">
                    Consider redistributing patients or adding support staff.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabs for different views */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="bg-white border">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="doctors">Doctor Stats</TabsTrigger>
            <TabsTrigger value="queue">Live Queue</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Queue by Doctor Chart */}
              <Card className="bg-white shadow-sm">
                <CardHeader>
                  <CardTitle className="text-[#2C3E2C]">Queue Status by Doctor</CardTitle>
                  <CardDescription>Current waiting, in-progress, and completed consultations</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={doctorQueueData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="waiting" fill="#FFA726" name="Waiting" />
                      <Bar dataKey="inProgress" fill="#42A5F5" name="In Progress" />
                      <Bar dataKey="completed" fill="#4CAF50" name="Completed" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Urgency Distribution */}
              <Card className="bg-white shadow-sm">
                <CardHeader>
                  <CardTitle className="text-[#2C3E2C]">Patient Urgency Distribution</CardTitle>
                  <CardDescription>Breakdown of waiting patients by urgency level</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={urgencyData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {urgencyData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Doctor Stats Tab */}
          <TabsContent value="doctors" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {doctorStats.map((stat) => {
                const doctorWaiting = queueEntries.filter(
                  e => e.doctorId === stat.doctorId && e.status === 'waiting'
                ).length;
                const doctorInProgress = queueEntries.filter(
                  e => e.doctorId === stat.doctorId && e.status === 'in-progress'
                ).length;

                return (
                  <Card key={stat.doctorId} className="bg-white shadow-sm border-[#4CAF50]">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <CardTitle className="text-[#2C3E2C] text-lg">
                          {stat.doctorName}
                        </CardTitle>
                        <Badge 
                          variant="outline"
                          className={
                            stat.status === 'active' 
                              ? 'bg-green-100 text-green-800 border-green-300'
                              : 'bg-gray-100 text-gray-800 border-gray-300'
                          }
                        >
                          {stat.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Waiting</span>
                          <span className="text-[#C19A4A]">{doctorWaiting}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">In Progress</span>
                          <span className="text-blue-600">{doctorInProgress}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Completed</span>
                          <span className="text-green-600">{stat.completedToday}</span>
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t">
                          <span className="text-sm text-gray-600">Avg Wait Time</span>
                          <span className="text-[#4CAF50]">{stat.averageWaitTime}</span>
                        </div>
                      </div>

                      {/* Progress indicator */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs text-gray-600">
                          <span>Daily Progress</span>
                          <span>{stat.completedToday} consultations</span>
                        </div>
                        <Progress 
                          value={(stat.completedToday / 10) * 100} 
                          className="h-2"
                        />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* Live Queue Tab */}
          <TabsContent value="queue" className="space-y-4">
            <Card className="bg-white shadow-sm">
              <CardHeader>
                <CardTitle className="text-[#2C3E2C]">Live Queue Status</CardTitle>
                <CardDescription>Real-time view of all patients in the system</CardDescription>
              </CardHeader>
              <CardContent>
                {queueEntries.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <Users className="mx-auto h-12 w-12 mb-3 opacity-30" />
                    <p>No patients in queue</p>
                    <p className="text-sm">Queue entries will appear here when patients check in</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {queueEntries.map((entry) => (
                      <div
                        key={entry.id}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          entry.status === 'in-progress'
                            ? 'border-blue-400 bg-blue-50'
                            : entry.status === 'completed'
                            ? 'border-gray-300 bg-gray-50 opacity-60'
                            : entry.status === 'cancelled'
                            ? 'border-gray-300 bg-gray-50 opacity-40'
                            : 'border-gray-200 bg-white'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[#4CAF50] text-white">
                                {entry.status === 'waiting' ? entry.queuePosition : '•'}
                              </div>
                              <div>
                                <h3 className="text-[#2C3E2C] mb-1">{entry.patientName}</h3>
                                <p className="text-sm text-gray-600">{entry.doctorName}</p>
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-2 ml-11">
                              <Badge variant="outline" className={getUrgencyColor(entry.urgency)}>
                                {entry.urgency === 'emergency' && <AlertCircle className="mr-1 h-3 w-3" />}
                                {entry.urgency.charAt(0).toUpperCase() + entry.urgency.slice(1)}
                              </Badge>
                              <Badge variant="outline" className={getStatusColor(entry.status)}>
                                {entry.status.charAt(0).toUpperCase() + entry.status.slice(1).replace('-', ' ')}
                              </Badge>
                            </div>

                            <div className="ml-11 mt-3 grid grid-cols-2 gap-2 text-sm text-gray-600">
                              <div className="flex items-center">
                                <Calendar className="mr-2 h-4 w-4 text-[#C19A4A]" />
                                <span>{entry.consultationType}</span>
                              </div>
                              <div className="flex items-center">
                                <Clock className="mr-2 h-4 w-4 text-[#C19A4A]" />
                                <span>{entry.appointmentTime}</span>
                              </div>
                              {entry.status === 'waiting' && (
                                <div className="flex items-center col-span-2">
                                  <User className="mr-2 h-4 w-4 text-[#4CAF50]" />
                                  <span>Est. wait: {entry.estimatedWaitTime}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
