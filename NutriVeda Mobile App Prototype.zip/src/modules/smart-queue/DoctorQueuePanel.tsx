import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Progress } from '../../components/ui/progress';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../../components/ui/alert-dialog';
import { Clock, User, Calendar, AlertCircle, CheckCircle, XCircle, Play } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import {
  QueueEntry,
  getQueueByDoctor,
  markAsInProgress,
  markAsCompleted,
  cancelAppointment,
  getNextPatient,
  updateQueuePositions,
  getDoctorStats
} from './QueueManager';

interface DoctorQueuePanelProps {
  doctorId: string;
  doctorName: string;
}

export const DoctorQueuePanel: React.FC<DoctorQueuePanelProps> = ({ doctorId, doctorName }) => {
  const [queueEntries, setQueueEntries] = useState<QueueEntry[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<QueueEntry | null>(null);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [stats, setStats] = useState({ activePatients: 0, completedToday: 0, averageWaitTime: "0 mins" });

  // Load queue data
  const loadQueueData = () => {
    const entries = getQueueByDoctor(doctorId);
    setQueueEntries(entries);
    
    const doctorStats = getDoctorStats(doctorId);
    if (doctorStats.length > 0) {
      setStats({
        activePatients: doctorStats[0].activePatients,
        completedToday: doctorStats[0].completedToday,
        averageWaitTime: doctorStats[0].averageWaitTime
      });
    }
  };

  useEffect(() => {
    loadQueueData();
    // Refresh queue every 30 seconds
    const interval = setInterval(loadQueueData, 30000);
    return () => clearInterval(interval);
  }, [doctorId]);

  const handleNextPatient = () => {
    const nextPatient = getNextPatient(doctorId);
    if (nextPatient) {
      markAsInProgress(nextPatient.id);
      updateQueuePositions(doctorId);
      loadQueueData();
      toast.success(`Started consultation with ${nextPatient.patientName}`, {
        description: `${nextPatient.consultationType}`,
      });
    } else {
      toast.info("No patients waiting in queue");
    }
  };

  const handleMarkCompleted = (entry: QueueEntry) => {
    markAsCompleted(entry.id);
    updateQueuePositions(doctorId);
    loadQueueData();
    toast.success(`Consultation completed for ${entry.patientName}`, {
      description: "Patient record has been updated",
    });
  };

  const handleCancelAppointment = () => {
    if (selectedEntry) {
      cancelAppointment(selectedEntry.id);
      updateQueuePositions(doctorId);
      loadQueueData();
      toast.error(`Appointment cancelled for ${selectedEntry.patientName}`, {
        description: "Patient has been notified",
      });
      setShowCancelDialog(false);
      setSelectedEntry(null);
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "emergency": return "bg-red-100 text-red-800 border-red-300";
      case "urgent": return "bg-orange-100 text-orange-800 border-orange-300";
      default: return "bg-green-100 text-green-800 border-green-300";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "in-progress": return "bg-blue-100 text-blue-800 border-blue-300";
      case "completed": return "bg-green-100 text-green-800 border-green-300";
      case "cancelled": return "bg-gray-100 text-gray-800 border-gray-300";
      default: return "bg-yellow-100 text-yellow-800 border-yellow-300";
    }
  };

  const waitingPatients = queueEntries.filter(e => e.status === "waiting");
  const inProgressPatients = queueEntries.filter(e => e.status === "in-progress");
  const completedToday = queueEntries.filter(e => e.status === "completed");

  return (
    <div className="min-h-screen bg-[#FAFAF5] p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-[#2C3E2C]">Smart Queue - {doctorName}</h1>
            <p className="text-gray-600">Manage your patient consultations efficiently</p>
          </div>
          <Button 
            onClick={handleNextPatient}
            disabled={waitingPatients.length === 0}
            className="bg-[#4CAF50] hover:bg-[#45a049]"
            size="lg"
          >
            <Play className="mr-2 h-5 w-5" />
            Next Patient
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-[#4CAF50] bg-white shadow-sm">
            <CardHeader className="pb-3">
              <CardDescription>Waiting in Queue</CardDescription>
              <CardTitle className="text-[#4CAF50]">{waitingPatients.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <Clock className="mr-1 h-4 w-4" />
                Active patients
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-300 bg-white shadow-sm">
            <CardHeader className="pb-3">
              <CardDescription>In Progress</CardDescription>
              <CardTitle className="text-blue-600">{inProgressPatients.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <User className="mr-1 h-4 w-4" />
                Current consultation
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-300 bg-white shadow-sm">
            <CardHeader className="pb-3">
              <CardDescription>Completed Today</CardDescription>
              <CardTitle className="text-green-600">{stats.completedToday}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <CheckCircle className="mr-1 h-4 w-4" />
                Consultations done
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#C19A4A] bg-white shadow-sm">
            <CardHeader className="pb-3">
              <CardDescription>Avg. Wait Time</CardDescription>
              <CardTitle className="text-[#C19A4A]">{stats.averageWaitTime}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-gray-600">
                <Calendar className="mr-1 h-4 w-4" />
                Per patient
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Queue List */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#2C3E2C]">Patient Queue</CardTitle>
            <CardDescription>Manage your consultation queue in priority order</CardDescription>
          </CardHeader>
          <CardContent>
            {queueEntries.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <User className="mx-auto h-12 w-12 mb-3 opacity-30" />
                <p>No patients in queue</p>
                <p className="text-sm">Your queue will appear here when patients check in</p>
              </div>
            ) : (
              <div className="space-y-3">
                {queueEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      entry.status === "in-progress" 
                        ? "border-blue-400 bg-blue-50" 
                        : entry.status === "completed"
                        ? "border-gray-300 bg-gray-50 opacity-60"
                        : entry.status === "cancelled"
                        ? "border-gray-300 bg-gray-50 opacity-40"
                        : "border-gray-200 bg-white hover:border-[#4CAF50]"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[#4CAF50] text-white">
                            {entry.status === "waiting" ? entry.queuePosition : "•"}
                          </div>
                          <div>
                            <h3 className="text-[#2C3E2C] mb-1">{entry.patientName}</h3>
                            <p className="text-sm text-gray-600">{entry.patientEmail}</p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 ml-11">
                          <Badge variant="outline" className={getUrgencyColor(entry.urgency)}>
                            {entry.urgency === "emergency" && <AlertCircle className="mr-1 h-3 w-3" />}
                            {entry.urgency.charAt(0).toUpperCase() + entry.urgency.slice(1)}
                          </Badge>
                          <Badge variant="outline" className={getStatusColor(entry.status)}>
                            {entry.status === "in-progress" && <Play className="mr-1 h-3 w-3" />}
                            {entry.status === "completed" && <CheckCircle className="mr-1 h-3 w-3" />}
                            {entry.status === "cancelled" && <XCircle className="mr-1 h-3 w-3" />}
                            {entry.status.charAt(0).toUpperCase() + entry.status.slice(1).replace("-", " ")}
                          </Badge>
                        </div>

                        <div className="ml-11 mt-3 space-y-1 text-sm text-gray-600">
                          <div className="flex items-center">
                            <Calendar className="mr-2 h-4 w-4 text-[#C19A4A]" />
                            <span>{entry.consultationType}</span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4 text-[#C19A4A]" />
                            <span>Appointment: {entry.appointmentTime} • Check-in: {entry.checkInTime}</span>
                          </div>
                          {entry.status === "waiting" && (
                            <div className="flex items-center gap-2 mt-2">
                              <span className="text-[#4CAF50]">Est. wait time:</span>
                              <Progress value={(1 / entry.queuePosition) * 100} className="flex-1 max-w-[200px]" />
                              <span>{entry.estimatedWaitTime}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-2 ml-4">
                        {entry.status === "waiting" && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => {
                                markAsInProgress(entry.id);
                                updateQueuePositions(doctorId);
                                loadQueueData();
                                toast.success(`Started consultation with ${entry.patientName}`);
                              }}
                              className="bg-[#4CAF50] hover:bg-[#45a049]"
                            >
                              <Play className="mr-1 h-4 w-4" />
                              Start
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedEntry(entry);
                                setShowCancelDialog(true);
                              }}
                              className="border-red-300 text-red-600 hover:bg-red-50"
                            >
                              <XCircle className="mr-1 h-4 w-4" />
                              Cancel
                            </Button>
                          </>
                        )}
                        {entry.status === "in-progress" && (
                          <Button
                            size="sm"
                            onClick={() => handleMarkCompleted(entry)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="mr-1 h-4 w-4" />
                            Complete
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Cancel Confirmation Dialog */}
      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Appointment?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel the appointment for{" "}
              <span className="font-semibold text-[#2C3E2C]">{selectedEntry?.patientName}</span>?
              This action will remove them from the queue and notify the patient.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setSelectedEntry(null)}>
              Keep Appointment
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCancelAppointment}
              className="bg-red-600 hover:bg-red-700"
            >
              Yes, Cancel
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
