import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Progress } from '../../components/ui/progress';
import { Alert, AlertDescription } from '../../components/ui/alert';
import { Clock, User, Calendar, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { QueueEntry, getQueueByPatient } from './QueueManager';

interface PatientQueueStatusProps {
  patientId: string;
  patientName: string;
}

export const PatientQueueStatus: React.FC<PatientQueueStatusProps> = ({ patientId, patientName }) => {
  const [queueEntry, setQueueEntry] = useState<QueueEntry | undefined>(undefined);
  const [previousPosition, setPreviousPosition] = useState<number | null>(null);

  const loadQueueData = () => {
    const entry = getQueueByPatient(patientId);
    
    // Check if position changed
    if (entry && previousPosition !== null && entry.queuePosition !== previousPosition) {
      if (entry.queuePosition < previousPosition) {
        toast.success("You've moved up in the queue!", {
          description: `Now at position ${entry.queuePosition}`,
        });
      }
    }
    
    // If patient is next (position 1) and status is waiting, show notification
    if (entry && entry.queuePosition === 1 && entry.status === 'waiting') {
      toast.success("You're next in line!", {
        description: 'Your consultation will begin soon',
      });
    }
    
    setPreviousPosition(entry?.queuePosition ?? null);
    setQueueEntry(entry);
  };

  useEffect(() => {
    loadQueueData();
    // Refresh every 15 seconds
    const interval = setInterval(loadQueueData, 15000);
    return () => clearInterval(interval);
  }, [patientId]);

  const getProgressValue = () => {
    if (!queueEntry) return 0;
    if (queueEntry.status === 'in-progress') return 90;
    if (queueEntry.status === 'waiting' && queueEntry.queuePosition === 1) return 75;
    if (queueEntry.status === 'waiting' && queueEntry.queuePosition === 2) return 50;
    if (queueEntry.status === 'waiting' && queueEntry.queuePosition === 3) return 30;
    return 10;
  };

  const getStatusBadge = () => {
    if (!queueEntry) return null;

    switch (queueEntry.status) {
      case 'in-progress':
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-300">
            <CheckCircle className="mr-1 h-3 w-3" />
            In Progress
          </Badge>
        );
      case 'waiting':
        return (
          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">
            <Clock className="mr-1 h-3 w-3" />
            Waiting
          </Badge>
        );
      case 'completed':
        return (
          <Badge className="bg-green-100 text-green-800 border-green-300">
            <CheckCircle className="mr-1 h-3 w-3" />
            Completed
          </Badge>
        );
      default:
        return null;
    }
  };

  const getUrgencyBadge = () => {
    if (!queueEntry) return null;

    switch (queueEntry.urgency) {
      case 'emergency':
        return (
          <Badge className="bg-red-100 text-red-800 border-red-300">
            <AlertCircle className="mr-1 h-3 w-3" />
            Emergency
          </Badge>
        );
      case 'urgent':
        return (
          <Badge className="bg-orange-100 text-orange-800 border-orange-300">
            <AlertCircle className="mr-1 h-3 w-3" />
            Urgent
          </Badge>
        );
      default:
        return null;
    }
  };

  if (!queueEntry) {
    return (
      <div className="min-h-screen bg-[#FAFAF5] p-6">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-white shadow-sm">
            <CardHeader>
              <CardTitle className="text-[#2C3E2C]">Queue Status</CardTitle>
              <CardDescription>Your appointment status will appear here</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12 text-gray-500">
                <Clock className="mx-auto h-12 w-12 mb-3 opacity-30" />
                <p>You are not currently in any queue</p>
                <p className="text-sm mt-2">Check in for your appointment to join the queue</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF5] p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Welcome Header */}
        <div className="text-center">
          <h1 className="text-[#2C3E2C] mb-2">Welcome, {patientName}</h1>
          <p className="text-gray-600">Your consultation queue status</p>
        </div>

        {/* Next in Line Alert */}
        {queueEntry.status === 'waiting' && queueEntry.queuePosition === 1 && (
          <Alert className="border-[#4CAF50] bg-green-50">
            <AlertCircle className="h-4 w-4 text-[#4CAF50]" />
            <AlertDescription className="text-[#2C3E2C]">
              🎉 <strong>You're next!</strong> Your consultation with {queueEntry.doctorName} will begin shortly.
            </AlertDescription>
          </Alert>
        )}

        {/* In Progress Alert */}
        {queueEntry.status === 'in-progress' && (
          <Alert className="border-blue-500 bg-blue-50">
            <CheckCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-[#2C3E2C]">
              ✅ <strong>Your consultation is now in progress</strong> with {queueEntry.doctorName}
            </AlertDescription>
          </Alert>
        )}

        {/* Queue Position Card */}
        <Card className="bg-white shadow-lg border-[#4CAF50]">
          <CardHeader className="text-center pb-4">
            <div className="flex items-center justify-center gap-3 mb-3">
              {getStatusBadge()}
              {getUrgencyBadge()}
            </div>
            {queueEntry.status === 'waiting' && (
              <>
                <div className="text-6xl mb-2 text-[#4CAF50]">
                  #{queueEntry.queuePosition}
                </div>
                <CardTitle className="text-[#2C3E2C]">Your Position in Queue</CardTitle>
                <CardDescription>
                  {queueEntry.queuePosition === 1 
                    ? "You're next in line!" 
                    : `${queueEntry.queuePosition - 1} ${queueEntry.queuePosition - 1 === 1 ? 'person' : 'people'} ahead of you`}
                </CardDescription>
              </>
            )}
            {queueEntry.status === 'in-progress' && (
              <>
                <CardTitle className="text-[#2C3E2C] text-2xl">Consultation In Progress</CardTitle>
                <CardDescription>Currently with your doctor</CardDescription>
              </>
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Progress</span>
                <span className="text-[#4CAF50]">
                  {queueEntry.status === 'in-progress' ? 'Almost there!' : `Est. ${queueEntry.estimatedWaitTime}`}
                </span>
              </div>
              <Progress value={getProgressValue()} className="h-3" />
            </div>

            {/* Appointment Details */}
            <div className="space-y-4 pt-4 border-t">
              <div className="flex items-start gap-3">
                <User className="h-5 w-5 text-[#C19A4A] mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm text-gray-600">Doctor</div>
                  <div className="text-[#2C3E2C]">{queueEntry.doctorName}</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-[#C19A4A] mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm text-gray-600">Consultation Type</div>
                  <div className="text-[#2C3E2C]">{queueEntry.consultationType}</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-[#C19A4A] mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm text-gray-600">Scheduled Time</div>
                  <div className="text-[#2C3E2C]">{queueEntry.appointmentTime}</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-[#C19A4A] mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm text-gray-600">Check-in Time</div>
                  <div className="text-[#2C3E2C]">{queueEntry.checkInTime}</div>
                </div>
              </div>
            </div>

            {/* Estimated Wait Time Banner */}
            {queueEntry.status === 'waiting' && queueEntry.queuePosition > 1 && (
              <div className="mt-4 p-4 bg-gradient-to-r from-[#4CAF50]/10 to-[#C19A4A]/10 rounded-lg border border-[#4CAF50]/20">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-gray-600">Estimated Wait Time</div>
                    <div className="text-[#4CAF50]">{queueEntry.estimatedWaitTime}</div>
                  </div>
                  <Clock className="h-8 w-8 text-[#C19A4A] opacity-50" />
                </div>
              </div>
            )}

            {/* Information Box */}
            <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="mb-1">
                    <strong>Please remain nearby.</strong> You'll receive a notification when it's your turn.
                  </p>
                  <p className="text-xs text-blue-700">
                    Your queue status updates automatically every 15 seconds.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tips Card */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="text-[#2C3E2C] text-lg">While You Wait</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start gap-2">
                <span className="text-[#4CAF50] mt-0.5">✓</span>
                <span>Prepare any questions you want to discuss with your doctor</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#4CAF50] mt-0.5">✓</span>
                <span>Have your medical records and previous prescriptions ready</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#4CAF50] mt-0.5">✓</span>
                <span>Stay hydrated and relaxed</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
