// Smart Queue Manager - Business Logic & Mock Data

export interface QueueEntry {
  id: string;
  doctorId: string;
  doctorName: string;
  patientId: string;
  patientName: string;
  patientEmail: string;
  urgency: "normal" | "urgent" | "emergency";
  status: "waiting" | "in-progress" | "completed" | "cancelled";
  queuePosition: number;
  estimatedWaitTime: string;
  appointmentTime: string;
  checkInTime: string;
  consultationType: string;
}

export interface DoctorQueueStats {
  doctorId: string;
  doctorName: string;
  activePatients: number;
  completedToday: number;
  averageWaitTime: string;
  status: "active" | "away" | "offline";
}

// Mock data for queue entries
let mockQueueData: QueueEntry[] = [
  {
    id: "q1",
    doctorId: "doc1",
    doctorName: "Dr. Priya Sharma",
    patientId: "p1",
    patientName: "Ananya Reddy",
    patientEmail: "ananya@example.com",
    urgency: "normal",
    status: "waiting",
    queuePosition: 1,
    estimatedWaitTime: "5 mins",
    appointmentTime: "10:00 AM",
    checkInTime: "9:55 AM",
    consultationType: "Follow-up - Dosha Balance"
  },
  {
    id: "q2",
    doctorId: "doc1",
    doctorName: "Dr. Priya Sharma",
    patientId: "p2",
    patientName: "Rajesh Kumar",
    patientEmail: "rajesh@example.com",
    urgency: "urgent",
    status: "waiting",
    queuePosition: 2,
    estimatedWaitTime: "15 mins",
    appointmentTime: "10:15 AM",
    checkInTime: "10:10 AM",
    consultationType: "New Consultation"
  },
  {
    id: "q3",
    doctorId: "doc1",
    doctorName: "Dr. Priya Sharma",
    patientId: "p3",
    patientName: "Meera Patel",
    patientEmail: "meera@example.com",
    urgency: "normal",
    status: "waiting",
    queuePosition: 3,
    estimatedWaitTime: "30 mins",
    appointmentTime: "10:30 AM",
    checkInTime: "10:25 AM",
    consultationType: "Diet Plan Review"
  },
  {
    id: "q4",
    doctorId: "doc2",
    doctorName: "Dr. Amit Desai",
    patientId: "p4",
    patientName: "Kavita Singh",
    patientEmail: "kavita@example.com",
    urgency: "emergency",
    status: "in-progress",
    queuePosition: 1,
    estimatedWaitTime: "In Progress",
    appointmentTime: "10:00 AM",
    checkInTime: "9:58 AM",
    consultationType: "Emergency - Health Issues"
  },
  {
    id: "q5",
    doctorId: "doc2",
    doctorName: "Dr. Amit Desai",
    patientId: "p5",
    patientName: "Suresh Nair",
    patientEmail: "suresh@example.com",
    urgency: "normal",
    status: "waiting",
    queuePosition: 2,
    estimatedWaitTime: "20 mins",
    appointmentTime: "10:20 AM",
    checkInTime: "10:15 AM",
    consultationType: "Prakriti Assessment"
  },
  {
    id: "q6",
    doctorId: "doc3",
    doctorName: "Dr. Lakshmi Iyer",
    patientId: "p6",
    patientName: "Aditya Verma",
    patientEmail: "aditya@example.com",
    urgency: "normal",
    status: "waiting",
    queuePosition: 1,
    estimatedWaitTime: "10 mins",
    appointmentTime: "10:00 AM",
    checkInTime: "10:00 AM",
    consultationType: "Nutrition Counseling"
  }
];

// Mock doctor stats
const mockDoctorStats: DoctorQueueStats[] = [
  {
    doctorId: "doc1",
    doctorName: "Dr. Priya Sharma",
    activePatients: 3,
    completedToday: 5,
    averageWaitTime: "12 mins",
    status: "active"
  },
  {
    doctorId: "doc2",
    doctorName: "Dr. Amit Desai",
    activePatients: 2,
    completedToday: 4,
    averageWaitTime: "15 mins",
    status: "active"
  },
  {
    doctorId: "doc3",
    doctorName: "Dr. Lakshmi Iyer",
    activePatients: 1,
    completedToday: 3,
    averageWaitTime: "10 mins",
    status: "active"
  }
];

// Business Logic Functions

export const getAllQueueEntries = (): QueueEntry[] => {
  return [...mockQueueData].sort((a, b) => {
    // Sort by status first (in-progress, waiting, completed, cancelled)
    const statusOrder = { "in-progress": 0, "waiting": 1, "completed": 2, "cancelled": 3 };
    if (statusOrder[a.status] !== statusOrder[b.status]) {
      return statusOrder[a.status] - statusOrder[b.status];
    }
    // Then by urgency
    const urgencyOrder = { "emergency": 0, "urgent": 1, "normal": 2 };
    return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
  });
};

export const getQueueByDoctor = (doctorId: string): QueueEntry[] => {
  return mockQueueData
    .filter(entry => entry.doctorId === doctorId)
    .sort((a, b) => {
      // Sort by status first
      const statusOrder = { "in-progress": 0, "waiting": 1, "completed": 2, "cancelled": 3 };
      if (statusOrder[a.status] !== statusOrder[b.status]) {
        return statusOrder[a.status] - statusOrder[b.status];
      }
      // Then by urgency
      const urgencyOrder = { "emergency": 0, "urgent": 1, "normal": 2 };
      if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
        return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
      }
      // Finally by queue position
      return a.queuePosition - b.queuePosition;
    });
};

export const getQueueByPatient = (patientId: string): QueueEntry | undefined => {
  return mockQueueData.find(entry => entry.patientId === patientId && entry.status !== "completed" && entry.status !== "cancelled");
};

export const getDoctorStats = (doctorId?: string): DoctorQueueStats[] => {
  if (doctorId) {
    return mockDoctorStats.filter(stat => stat.doctorId === doctorId);
  }
  return mockDoctorStats;
};

export const markAsInProgress = (queueId: string): QueueEntry | null => {
  const entry = mockQueueData.find(e => e.id === queueId);
  if (entry) {
    entry.status = "in-progress";
    entry.estimatedWaitTime = "In Progress";
    return entry;
  }
  return null;
};

export const markAsCompleted = (queueId: string): QueueEntry | null => {
  const entry = mockQueueData.find(e => e.id === queueId);
  if (entry) {
    entry.status = "completed";
    entry.estimatedWaitTime = "Completed";
    // Update doctor stats
    const doctorStat = mockDoctorStats.find(s => s.doctorId === entry.doctorId);
    if (doctorStat) {
      doctorStat.completedToday += 1;
      doctorStat.activePatients = Math.max(0, doctorStat.activePatients - 1);
    }
    return entry;
  }
  return null;
};

export const cancelAppointment = (queueId: string): QueueEntry | null => {
  const entry = mockQueueData.find(e => e.id === queueId);
  if (entry) {
    entry.status = "cancelled";
    entry.estimatedWaitTime = "Cancelled";
    // Update doctor stats
    const doctorStat = mockDoctorStats.find(s => s.doctorId === entry.doctorId);
    if (doctorStat) {
      doctorStat.activePatients = Math.max(0, doctorStat.activePatients - 1);
    }
    return entry;
  }
  return null;
};

export const getNextPatient = (doctorId: string): QueueEntry | null => {
  const waitingPatients = mockQueueData
    .filter(entry => entry.doctorId === doctorId && entry.status === "waiting")
    .sort((a, b) => {
      // Sort by urgency first
      const urgencyOrder = { "emergency": 0, "urgent": 1, "normal": 2 };
      if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
        return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
      }
      // Then by position
      return a.queuePosition - b.queuePosition;
    });
  
  return waitingPatients.length > 0 ? waitingPatients[0] : null;
};

export const updateQueuePositions = (doctorId: string): void => {
  const doctorQueue = mockQueueData
    .filter(entry => entry.doctorId === doctorId && entry.status === "waiting")
    .sort((a, b) => {
      const urgencyOrder = { "emergency": 0, "urgent": 1, "normal": 2 };
      return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
    });
  
  doctorQueue.forEach((entry, index) => {
    entry.queuePosition = index + 1;
    // Recalculate estimated wait time (10 mins per patient)
    entry.estimatedWaitTime = `${(index + 1) * 10} mins`;
  });
};

export const getTotalWaitingPatients = (): number => {
  return mockQueueData.filter(entry => entry.status === "waiting").length;
};

export const getActiveDoctorsCount = (): number => {
  return mockDoctorStats.filter(stat => stat.status === "active").length;
};

export const getLongestQueue = (): { doctorName: string; count: number } | null => {
  const doctorQueues = mockDoctorStats.map(stat => ({
    doctorName: stat.doctorName,
    count: mockQueueData.filter(e => e.doctorId === stat.doctorId && e.status === "waiting").length
  }));
  
  if (doctorQueues.length === 0) return null;
  
  return doctorQueues.reduce((max, current) => current.count > max.count ? current : max);
};
