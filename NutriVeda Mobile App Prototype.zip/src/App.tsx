import { useState } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { 
  LayoutDashboard, 
  Users, 
  ClipboardList, 
  Calendar, 
  BarChart, 
  Settings as SettingsIcon, 
  Leaf,
  User,
  Stethoscope,
  ArrowRight,
  Bell,
  Heart,
  Plus,
  Search,
  Shield,
  ArrowLeft,
  Edit,
  Eye,
  Activity
} from 'lucide-react';

import logoImage from 'figma:asset/889d4ce0044cdf152176c30b31343b595aec5e22.png';

import PatientNutrition from './components/patient-nutrition';
import PatientForm from './components/patient-form';
import { SmartQueueDashboard } from './modules/smart-queue/SmartQueueDashboard';
import { DoctorQueuePanel } from './modules/smart-queue/DoctorQueuePanel';
import { PatientQueueStatus } from './modules/smart-queue/PatientQueueStatus';

interface Patient {
  id: string;
  name: string;
  age: string;
  gender: string;
  locality: string;
  occupation: string;
  bloodPressure: string;
  pulse: string;
  mainComplaint: string;
  allergies: string;
  dietaryPreference: string;
  dietaryPreferenceOther: string;
  smoking: boolean;
  drinking: boolean;
  otherHabits: string;
  prakruti: string[];
  ritu: string;
  agni: string;
  bowelHabits: string;
  bowelHabitsOther: string;
  sleepPattern: string[];
  sleepPatternOther: string;
  activityLevel: string;
  dateAdded: Date;
  addedBy: 'admin' | 'dietitian';
  status: 'active' | 'inactive';
  nutrition?: {
    calories: { current: number; target: number };
    protein: { current: number; target: number };
    carbs: { current: number; target: number };
    fats: { current: number; target: number };
    micronutrients: {
      vitaminA: number;
      vitaminC: number;
      vitaminD: number;
      iron: number;
      calcium: number;
      zinc: number;
      magnesium: number;
      folate: number;
    };
  };
  ayurvedicPrescription?: {
    recommendations: string[];
    doshaBalance: string;
    herbs: { name: string; dosage: string; timing: string }[];
  };
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'onboarding' | 'dashboard' | 'clients' | 'my-profile' | 'diet' | 'consultations' | 'reports' | 'settings' | 'add-patient' | 'edit-patient' | 'patient-nutrition' | 'smart-queue' | 'doctor-queue' | 'patient-queue'>('onboarding');
  const [userRole, setUserRole] = useState<string>('');
  const [step, setStep] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingPatientId, setEditingPatientId] = useState<string | null>(null);
  const [viewingPatientId, setViewingPatientId] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<'today' | 'tomorrow'>('today');
  const [selectedDoctor, setSelectedDoctor] = useState<string | null>(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [pendingDoctors, setPendingDoctors] = useState([
    {
      id: 'pending-1',
      name: 'Dr. Anita Verma',
      email: 'anita.verma@email.com',
      specialty: 'Ayurvedic Nutrition Specialist',
      experience: '5 years',
      qualifications: 'BAMS, MD (Ayurveda)',
      registrationDate: new Date('2024-03-15'),
      status: 'pending'
    },
    {
      id: 'pending-2',
      name: 'Dr. Vikash Singh',
      email: 'vikash.singh@email.com',
      specialty: 'Panchakosha Wellness Expert',
      experience: '7 years',
      qualifications: 'BAMS, Diploma in Yoga',
      registrationDate: new Date('2024-03-14'),
      status: 'pending'
    }
  ]);
  const [mySchedule, setMySchedule] = useState([
    {
      id: '1',
      patientName: 'Arjun Patel',
      type: 'Follow-up Consultation',
      time: '10:30 AM',
      duration: '30 mins',
      status: 'confirmed',
      notes: 'Review nutrition plan progress',
      patientContact: '+91 9876543210'
    },
    {
      id: '2',
      patientName: 'Rahul Mehta',
      type: 'Initial Assessment',
      time: '2:30 PM',
      duration: '45 mins',
      status: 'confirmed',
      notes: 'Weight management consultation',
      patientContact: '+91 9876543211'
    },
    {
      id: '3',
      patientName: 'Sneha Gupta',
      type: 'Follow-up',
      time: '4:00 PM',
      duration: '30 mins',
      status: 'pending',
      notes: 'Digestive health review',
      patientContact: '+91 9876543212'
    }
  ]);
  const [approvedDoctors, setApprovedDoctors] = useState([
    {
      id: '1',
      name: 'Dr. Priya Sharma',
      email: 'priya.sharma@email.com',
      specialty: 'Ayurvedic Nutrition Specialist',
      experience: '8 years',
      rating: 4.9,
      consultationFee: '₹800',
      image: 'PS',
      qualifications: 'BAMS, MD (Ayurveda)',
      status: 'approved',
      availability: {
        today: [
          { time: '9:00 AM', status: 'available' },
          { time: '10:30 AM', status: 'booked' },
          { time: '12:00 PM', status: 'available' },
          { time: '2:30 PM', status: 'available' },
          { time: '4:00 PM', status: 'booked' },
          { time: '5:30 PM', status: 'available' }
        ],
        tomorrow: [
          { time: '9:00 AM', status: 'available' },
          { time: '10:30 AM', status: 'available' },
          { time: '12:00 PM', status: 'available' },
          { time: '2:30 PM', status: 'booked' },
          { time: '4:00 PM', status: 'available' },
          { time: '5:30 PM', status: 'available' }
        ]
      }
    },
    {
      id: '2',
      name: 'Dr. Rajesh Kumar',
      email: 'rajesh.kumar@email.com',
      specialty: 'Panchakosha Wellness Expert',
      experience: '12 years',
      rating: 4.8,
      consultationFee: '₹1000',
      image: 'RK',
      qualifications: 'BAMS, PhD (Ayurveda)',
      status: 'approved',
      availability: {
        today: [
          { time: '8:30 AM', status: 'available' },
          { time: '10:00 AM', status: 'available' },
          { time: '11:30 AM', status: 'booked' },
          { time: '1:00 PM', status: 'available' },
          { time: '3:30 PM', status: 'available' },
          { time: '5:00 PM', status: 'booked' }
        ],
        tomorrow: [
          { time: '8:30 AM', status: 'booked' },
          { time: '10:00 AM', status: 'available' },
          { time: '11:30 AM', status: 'available' },
          { time: '1:00 PM', status: 'available' },
          { time: '3:30 PM', status: 'available' },
          { time: '5:00 PM', status: 'available' }
        ]
      }
    }
  ]);
  
  // Client's own profile data
  const clientProfile: Patient = {
    id: 'client-1',
    name: 'Arjun Patel',
    age: '32',
    gender: 'male',
    locality: 'Bangalore',
    occupation: 'Software Developer',
    bloodPressure: '125/82',
    pulse: '74',
    mainComplaint: 'Stress management and weight control',
    allergies: 'Peanuts',
    dietaryPreference: 'vegetarian',
    dietaryPreferenceOther: '',
    smoking: false,
    drinking: false,
    otherHabits: 'Regular yoga practice',
    prakruti: ['Vata', 'Pitta'],
    ritu: 'Varsha',
    agni: 'sama',
    bowelHabits: 'regular',
    bowelHabitsOther: '',
    sleepPattern: ['sound'],
    sleepPatternOther: '',
    activityLevel: 'moderate',
    dateAdded: new Date('2024-01-10'),
    addedBy: 'dietitian',
    status: 'active',
    nutrition: {
      calories: { current: 1850, target: 2000 },
      protein: { current: 52, target: 65 },
      carbs: { current: 190, target: 250 },
      fats: { current: 58, target: 65 },
      micronutrients: {
        vitaminA: 78,
        vitaminC: 85,
        vitaminD: 42,
        iron: 72,
        calcium: 65,
        zinc: 80,
        magnesium: 70,
        folate: 82
      }
    },
    ayurvedicPrescription: {
      recommendations: ['Follow Vata-Pitta balancing diet', 'Regular meditation', 'Avoid cold foods'],
      doshaBalance: 'Balancing Vata | Supporting Pitta',
      herbs: [
        { name: 'Ashwagandha', dosage: '500mg', timing: 'Morning with warm milk' },
        { name: 'Brahmi', dosage: '1 tsp', timing: 'Evening before dinner' },
        { name: 'Tulsi Tea', dosage: '1 cup', timing: 'After evening meal' }
      ]
    }
  };

  const [patients, setPatients] = useState<Patient[]>([
    {
      id: '1',
      name: 'Priya Sharma',
      age: '28',
      gender: 'female',
      locality: 'Mumbai',
      occupation: 'Software Engineer',
      bloodPressure: '120/80',
      pulse: '72',
      mainComplaint: 'Digestive issues',
      allergies: 'None',
      dietaryPreference: 'vegetarian',
      dietaryPreferenceOther: '',
      smoking: false,
      drinking: false,
      otherHabits: '',
      prakruti: ['Pitta', 'Vata'],
      ritu: 'Varsha',
      agni: 'sama',
      bowelHabits: 'regular',
      bowelHabitsOther: '',
      sleepPattern: ['sound'],
      sleepPatternOther: '',
      activityLevel: 'moderate',
      dateAdded: new Date('2024-01-15'),
      addedBy: 'admin',
      status: 'active',
      nutrition: {
        calories: { current: 1650, target: 1800 },
        protein: { current: 45, target: 55 },
        carbs: { current: 180, target: 220 },
        fats: { current: 55, target: 60 },
        micronutrients: {
          vitaminA: 85,
          vitaminC: 92,
          vitaminD: 45,
          iron: 78,
          calcium: 68,
          zinc: 82,
          magnesium: 75,
          folate: 88
        }
      },
      ayurvedicPrescription: {
        recommendations: ['Follow Pitta-pacifying diet', 'Avoid spicy foods', 'Include cooling herbs'],
        doshaBalance: 'Balancing Pitta | Calming Vata',
        herbs: [
          { name: 'Triphala', dosage: '1 tsp', timing: 'Before bed with warm water' },
          { name: 'Aloe Vera Juice', dosage: '30ml', timing: 'Empty stomach morning' },
          { name: 'Fennel Tea', dosage: '1 cup', timing: 'After meals' }
        ]
      }
    },
    {
      id: '2',
      name: 'Rahul Mehta',
      age: '35',
      gender: 'male',
      locality: 'Delhi',
      occupation: 'Business Owner',
      bloodPressure: '130/85',
      pulse: '68',
      mainComplaint: 'Weight management',
      allergies: 'Dairy intolerance',
      dietaryPreference: 'non-vegetarian',
      dietaryPreferenceOther: '',
      smoking: false,
      drinking: true,
      otherHabits: 'Occasional social drinking',
      prakruti: ['Kapha'],
      ritu: 'Hemant',
      agni: 'tikshna',
      bowelHabits: 'regular',
      bowelHabitsOther: '',
      sleepPattern: ['disturbed', 'wakes-frequently'],
      sleepPatternOther: '',
      activityLevel: 'low',
      dateAdded: new Date('2024-02-10'),
      addedBy: 'admin',
      status: 'active',
      nutrition: {
        calories: { current: 2200, target: 2000 },
        protein: { current: 85, target: 80 },
        carbs: { current: 240, target: 200 },
        fats: { current: 95, target: 70 },
        micronutrients: {
          vitaminA: 72,
          vitaminC: 65,
          vitaminD: 38,
          iron: 85,
          calcium: 55,
          zinc: 78,
          magnesium: 68,
          folate: 62
        }
      },
      ayurvedicPrescription: {
        recommendations: ['Follow Kapha-reducing diet', 'Increase physical activity', 'Warm spices to boost metabolism'],
        doshaBalance: 'Reducing Kapha | Boosting Agni',
        herbs: [
          { name: 'Guggul', dosage: '500mg', timing: 'Twice daily after meals' },
          { name: 'Ginger Tea', dosage: '1 cup', timing: 'Morning on empty stomach' },
          { name: 'Trikatu', dosage: '1/2 tsp', timing: 'Before meals with honey' }
        ]
      }
    }
  ]);
  
  const [patientForm, setPatientForm] = useState({
    name: '',
    age: '',
    gender: '',
    locality: '',
    occupation: '',
    bloodPressure: '',
    pulse: '',
    mainComplaint: '',
    allergies: '',
    dietaryPreference: '',
    dietaryPreferenceOther: '',
    smoking: false,
    drinking: false,
    otherHabits: '',
    prakruti: [] as string[],
    ritu: '',
    agni: '',
    bowelHabits: '',
    bowelHabitsOther: '',
    sleepPattern: [] as string[],
    sleepPatternOther: '',
    activityLevel: ''
  });

  const handleRoleSelection = (role: string) => {
    setUserRole(role);
    setStep(2);
  };

  const handleLogin = () => {
    // Check if it's a doctor trying to register
    if (userRole === 'dietitian' && loginEmail && !approvedDoctors.find(doc => doc.email === loginEmail)) {
      // Add to pending doctors list and notify admin
      const newDoctor = {
        id: `pending-${Date.now()}`,
        name: 'Dr. ' + loginEmail.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
        email: loginEmail,
        specialty: 'Ayurvedic Specialist',
        experience: 'To be verified',
        qualifications: 'To be verified',
        registrationDate: new Date(),
        status: 'pending'
      };
      
      setPendingDoctors(prev => [newDoctor, ...prev]);
      
      // Show success message to doctor
      alert('🎉 Registration Request Submitted!\n\n✅ Your application has been sent to the admin\n⏳ You will be notified once approved\n📋 Admin will review your credentials and enable your scheduling slots\n\nThank you for joining our Ayurvedic platform!');
      
      setCurrentScreen('onboarding');
      setUserRole('');
      setStep(1);
      setLoginEmail('');
      return;
    }
    
    setCurrentScreen('dashboard');
  };

  const handleAddPatient = () => {
    setEditingPatientId(null);
    setCurrentScreen('add-patient');
  };

  const handleEditPatient = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    if (patient) {
      setEditingPatientId(patientId);
      setPatientForm({
        name: patient.name,
        age: patient.age,
        gender: patient.gender,
        locality: patient.locality,
        occupation: patient.occupation,
        bloodPressure: patient.bloodPressure,
        pulse: patient.pulse,
        mainComplaint: patient.mainComplaint,
        allergies: patient.allergies,
        dietaryPreference: patient.dietaryPreference,
        dietaryPreferenceOther: patient.dietaryPreferenceOther,
        smoking: patient.smoking,
        drinking: patient.drinking,
        otherHabits: patient.otherHabits,
        prakruti: patient.prakruti,
        ritu: patient.ritu,
        agni: patient.agni,
        bowelHabits: patient.bowelHabits,
        bowelHabitsOther: patient.bowelHabitsOther,
        sleepPattern: patient.sleepPattern,
        sleepPatternOther: patient.sleepPatternOther,
        activityLevel: patient.activityLevel
      });
      setCurrentScreen('edit-patient');
    }
  };

  const handleBackToClients = () => {
    if (userRole === 'client') {
      setCurrentScreen('my-profile');
    } else {
      setCurrentScreen('clients'); // For admin/dietitian, go back to clients management
    }
    setSearchQuery('');
    setEditingPatientId(null);
    setViewingPatientId(null);
    setPatientForm({
      name: '',
      age: '',
      gender: '',
      locality: '',
      occupation: '',
      bloodPressure: '',
      pulse: '',
      mainComplaint: '',
      allergies: '',
      dietaryPreference: '',
      dietaryPreferenceOther: '',
      smoking: false,
      drinking: false,
      otherHabits: '',
      prakruti: [],
      ritu: '',
      agni: '',
      bowelHabits: '',
      bowelHabitsOther: '',
      sleepPattern: [],
      sleepPatternOther: '',
      activityLevel: ''
    });
  };

  const handleViewPatientNutrition = (patientId: string) => {
    setViewingPatientId(patientId);
    setCurrentScreen('patient-nutrition');
  };

  const handleFormChange = (field: string, value: string | string[]) => {
    setPatientForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCheckboxChange = (field: 'prakruti' | 'sleepPattern', value: string, checked: boolean) => {
    setPatientForm(prev => ({
      ...prev,
      [field]: checked 
        ? [...prev[field], value]
        : prev[field].filter(item => item !== value)
    }));
  };

  const handleBooleanChange = (field: string, checked: boolean) => {
    setPatientForm(prev => ({
      ...prev,
      [field]: checked
    }));
  };

  const handleSavePatient = () => {
    if (!patientForm.name || !patientForm.age || !patientForm.gender) {
      alert('Please fill in all required fields (Name, Age, Gender)');
      return;
    }

    if (editingPatientId) {
      setPatients(prev => prev.map(patient => 
        patient.id === editingPatientId 
          ? { 
              ...patient, 
              ...patientForm,
              dateAdded: patient.dateAdded,
              addedBy: patient.addedBy,
              status: patient.status
            }
          : patient
      ));
      alert('Patient updated successfully!');
    } else {
      const newPatient: Patient = {
        id: Date.now().toString(),
        ...patientForm,
        dateAdded: new Date(),
        addedBy: userRole === 'admin' ? 'admin' : 'dietitian',
        status: 'active'
      };
      setPatients(prev => [newPatient, ...prev]);
      alert('Patient saved successfully!');
    }
    
    handleBackToClients();
  };

  const handleSaveNutrition = (nutritionData: any) => {
    if (!viewingPatientId) return;
    
    setPatients(prev => prev.map(patient => 
      patient.id === viewingPatientId 
        ? {
            ...patient,
            ...nutritionData
          }
        : patient
    ));
  };

  const handleApproveDoctorRegistration = (doctorId: string) => {
    const pendingDoctor = pendingDoctors.find(doc => doc.id === doctorId);
    if (pendingDoctor) {
      const approvedDoctor = {
        ...pendingDoctor,
        id: `approved-${Date.now()}`,
        rating: 4.5,
        consultationFee: '₹750',
        image: pendingDoctor.name.split(' ').slice(1).map(n => n[0]).join('').toUpperCase(),
        status: 'approved',
        availability: {
          today: [
            { time: '9:00 AM', status: 'available' },
            { time: '11:00 AM', status: 'available' },
            { time: '2:00 PM', status: 'available' },
            { time: '4:00 PM', status: 'available' },
            { time: '5:30 PM', status: 'available' }
          ],
          tomorrow: [
            { time: '9:00 AM', status: 'available' },
            { time: '11:00 AM', status: 'available' },
            { time: '2:00 PM', status: 'available' },
            { time: '4:00 PM', status: 'available' },
            { time: '5:30 PM', status: 'available' }
          ]
        }
      };
      
      setApprovedDoctors(prev => [approvedDoctor, ...prev]);
      setPendingDoctors(prev => prev.filter(doc => doc.id !== doctorId));
      alert('Doctor approved successfully! They can now accept consultation bookings.');
    }
  };

  const handleRejectDoctorRegistration = (doctorId: string) => {
    setPendingDoctors(prev => prev.filter(doc => doc.id !== doctorId));
    alert('Doctor registration rejected.');
  };

  const handleCancelAppointment = (appointmentId: string) => {
    const appointment = mySchedule.find(apt => apt.id === appointmentId);
    if (appointment) {
      const confirmCancel = confirm(
        `Cancel appointment with ${appointment.patientName}?\n\n` +
        `Time: ${appointment.time}\n` +
        `Type: ${appointment.type}\n\n` +
        `The patient will be notified about the cancellation.`
      );
      
      if (confirmCancel) {
        setMySchedule(prev => prev.filter(apt => apt.id !== appointmentId));
        alert(`✅ Appointment with ${appointment.patientName} has been cancelled.\n📱 Patient notification sent to ${appointment.patientContact}`);
      }
    }
  };

  const handleRescheduleAppointment = (appointmentId: string) => {
    const appointment = mySchedule.find(apt => apt.id === appointmentId);
    if (appointment) {
      alert(`📅 Reschedule feature for ${appointment.patientName}\n\nThis would open a calendar to select new time slots.`);
    }
  };

  const handleToggleTimeSlot = (time: string, currentStatus: 'available' | 'blocked') => {
    const newStatus = currentStatus === 'available' ? 'blocked' : 'available';
    const action = newStatus === 'blocked' ? 'block' : 'unblock';
    
    if (confirm(`${action.charAt(0).toUpperCase() + action.slice(1)} ${time} slot?`)) {
      // Update doctor's availability
      setApprovedDoctors(prev => prev.map(doctor => {
        if (doctor.id === '1') { // Assuming current doctor is Dr. Priya Sharma
          return {
            ...doctor,
            availability: {
              ...doctor.availability,
              today: doctor.availability.today.map(slot => 
                slot.time === time 
                  ? { ...slot, status: newStatus === 'blocked' ? 'booked' : 'available' }
                  : slot
              )
            }
          };
        }
        return doctor;
      }));
      
      alert(`✅ ${time} slot has been ${newStatus === 'blocked' ? 'blocked' : 'unblocked'}.`);
    }
  };

  const handleLogout = () => {
    setCurrentScreen('onboarding');
    setUserRole('');
    setStep(1);
    setSearchQuery('');
    setEditingPatientId(null);
    setViewingPatientId(null);
    setLoginEmail('');
    setPatientForm({
      name: '',
      age: '',
      gender: '',
      locality: '',
      occupation: '',
      bloodPressure: '',
      pulse: '',
      mainComplaint: '',
      allergies: '',
      dietaryPreference: '',
      dietaryPreferenceOther: '',
      smoking: false,
      drinking: false,
      otherHabits: '',
      prakruti: [],
      ritu: '',
      agni: '',
      bowelHabits: '',
      bowelHabitsOther: '',
      sleepPattern: [],
      sleepPatternOther: '',
      activityLevel: ''
    });
  };

  // Onboarding Screen
  if (currentScreen === 'onboarding') {
    if (step === 1) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50 p-4 flex flex-col">
          <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
            <div className="text-center mb-8">
              <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-white flex items-center justify-center shadow-lg">
                <img 
                  src={logoImage} 
                  alt="Zyra Logo" 
                  className="w-28 h-28 rounded-full object-cover"
                />
              </div>
              <p className="text-green-600">Modern Nutrition with Ancient Wisdom</p>
            </div>

            <Card className="w-full shadow-lg border-green-100">
              <CardHeader className="text-center">
                <CardTitle className="text-green-800">Choose Your Role</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  variant="outline"
                  className="w-full h-16 flex items-center justify-between p-4 border-2 hover:border-primary"
                  onClick={() => handleRoleSelection('dietitian')}
                >
                  <div className="flex items-center space-x-3">
                    <Stethoscope className="h-6 w-6 text-primary" />
                    <div className="text-left">
                      <div className="font-medium">Ayurvedic Dietitian</div>
                      <div className="text-sm text-gray-500">Manage clients & create diet plans</div>
                    </div>
                  </div>
                  <ArrowRight className="h-5 w-5" />
                </Button>

                <Button
                  variant="outline"
                  className="w-full h-16 flex items-center justify-between p-4 border-2 hover:border-primary"
                  onClick={() => handleRoleSelection('client')}
                >
                  <div className="flex items-center space-x-3">
                    <User className="h-6 w-6 text-secondary" />
                    <div className="text-left">
                      <div className="font-medium">Client</div>
                      <div className="text-sm text-gray-500">Access your personalized diet plans</div>
                    </div>
                  </div>
                  <ArrowRight className="h-5 w-5" />
                </Button>

                <Button
                  variant="outline"
                  className="w-full h-16 flex items-center justify-between p-4 border-2 hover:border-primary"
                  onClick={() => handleRoleSelection('admin')}
                >
                  <div className="flex items-center space-x-3">
                    <Shield className="h-6 w-6 text-blue-600" />
                    <div className="text-left">
                      <div className="font-medium">Admin</div>
                      <div className="text-sm text-gray-500">Manage system settings & users</div>
                    </div>
                  </div>
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50 p-4 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
          <div className="text-center mb-8">
            <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-blue-100 flex items-center justify-center">
              <Heart className="h-16 w-16 text-blue-600" />
            </div>
            <h2 className="text-2xl mb-2 text-green-800">Welcome Back</h2>
            <p className="text-green-600">Sign in to continue</p>
          </div>

          <Card className="w-full shadow-lg border-green-100">
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label>Email Address</Label>
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="border-green-200"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                />
              </div>
              {userRole === 'dietitian' && (
                <div className="p-4 bg-gradient-to-r from-blue-50 to-green-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start space-x-2">
                    <div className="text-blue-600 mt-0.5">🩺</div>
                    <div>
                      <p className="text-sm text-blue-800 font-medium mb-1">
                        New Doctor Registration
                      </p>
                      <p className="text-xs text-blue-700">
                        After entering your email, your registration request will be instantly sent to our admin team for approval. You'll be able to schedule consultation slots once approved.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              <Button 
                onClick={handleLogin}
                className="w-full bg-primary hover:bg-primary/90"
              >
                Continue
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Dashboard Screen
  const renderDashboard = () => {
    const greeting = userRole === 'dietitian' ? 'Dr. Priya' : 
                     userRole === 'admin' ? 'Admin' : 'Arjun';
    
    const subtitle = userRole === 'dietitian' ? 'Ready to help clients today?' : 
                     userRole === 'admin' ? 'System management dashboard' : 
                     'Continue your wellness journey';

    return (
      <div className="p-4 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl text-green-800">Good morning, {greeting}! 🌞</h1>
            <p className="text-green-600">{subtitle}</p>
          </div>
          <div className="relative">
            <Bell className="h-6 w-6 text-green-700" />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              {userRole === 'dietitian' ? 
                Math.max(3, patients.filter(p => p.addedBy === 'admin').length) : 3}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">
                    {userRole === 'dietitian' ? 'Active Clients' : 
                     userRole === 'admin' ? 'Total Users' : 'Days on Plan'}
                  </p>
                  <p className="text-xl">
                    {userRole === 'dietitian' ? patients.length.toString() : 
                     userRole === 'admin' ? patients.length.toString() : '12'}
                  </p>
                  {userRole === 'dietitian' && (
                    <p className="text-xs text-gray-500">
                      ({patients.filter(p => p.addedBy === 'admin').length} from admin)
                    </p>
                  )}
                </div>
                <Users className="h-5 w-5 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">
                    {userRole === 'dietitian' ? 'Consultations' : 
                     userRole === 'admin' ? 'Dietitians' : 'Wellness Score'}
                  </p>
                  <p className="text-xl">
                    {userRole === 'dietitian' ? '8' : 
                     userRole === 'admin' ? '12' : '85%'}
                  </p>
                </div>
                <Calendar className="h-5 w-5 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-green-800">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="h-12 flex flex-col space-y-1"
                onClick={() => {
                  if (userRole === 'admin' || userRole === 'dietitian') {
                    setCurrentScreen('clients');
                  } else if (userRole === 'client') {
                    setCurrentScreen('my-profile');
                  }
                }}
              >
                <Plus className="h-4 w-4" />
                <span className="text-xs">
                  {userRole === 'dietitian' ? 'Clients' : 
                   userRole === 'admin' ? 'Patients' : 'My Profile'}
                </span>
              </Button>
              <Button 
                variant="outline" 
                className="h-12 flex flex-col space-y-1"
                onClick={() => {
                  if (userRole === 'client') {
                    setCurrentScreen('diet');
                  } else if (userRole === 'admin') {
                    setCurrentScreen('consultations');
                  }
                }}
              >
                <ClipboardList className="h-4 w-4" />
                <span className="text-xs">
                  {userRole === 'dietitian' ? 'Create Plan' : 
                   userRole === 'admin' ? 'Doctor Approvals' : 'View Plan'}
                </span>
              </Button>
              <Button 
                variant="outline" 
                className="h-12 flex flex-col space-y-1"
                onClick={() => setCurrentScreen('smart-queue')}
              >
                <Activity className="h-4 w-4" />
                <span className="text-xs">
                  {userRole === 'admin' ? 'Queue Dashboard' : 
                   userRole === 'dietitian' ? 'My Queue' : 'Queue Status'}
                </span>
              </Button>
              <Button 
                variant="outline" 
                className="h-12 flex flex-col space-y-1"
                onClick={() => setCurrentScreen('consultations')}
              >
                <Calendar className="h-4 w-4" />
                <span className="text-xs">
                  {userRole === 'admin' ? 'Manage Doctors' : 
                   userRole === 'dietitian' ? 'My Schedule' : 'Book Consult'}
                </span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Admin Notifications - Doctor Registration Requests */}
        {userRole === 'admin' && pendingDoctors.length > 0 && (
          <Card className="shadow-lg bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 animate-pulse">
            <CardHeader className="pb-3">
              <CardTitle className="text-amber-800 flex items-center">
                <Bell className="h-6 w-6 mr-2 animate-bounce" />
                🔔 New Doctor Registration Alert!
              </CardTitle>
              <p className="text-sm text-amber-700">
                {pendingDoctors.length} doctor{pendingDoctors.length > 1 ? 's' : ''} waiting for approval to join the platform
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingDoctors.slice(0, 2).map((doctor) => (
                  <div key={doctor.id} className="bg-white p-4 rounded-lg border-2 border-amber-200 shadow-sm">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className="h-12 w-12 bg-gradient-to-br from-amber-400 to-amber-600 text-white rounded-full flex items-center justify-center font-medium">
                          👨‍⚕️
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{doctor.name}</h4>
                          <p className="text-sm text-gray-600">{doctor.email}</p>
                          <p className="text-sm text-amber-700 font-medium">{doctor.specialty}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            📅 Registered: {doctor.registrationDate.toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2">
                        <Button
                          size="sm"
                          className="bg-green-600 hover:bg-green-700 text-white shadow-md"
                          onClick={() => handleApproveDoctorRegistration(doctor.id)}
                        >
                          ✅ Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-300 text-red-600 hover:bg-red-50"
                          onClick={() => handleRejectDoctorRegistration(doctor.id)}
                        >
                          ❌ Reject
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {pendingDoctors.length > 2 && (
                  <div className="bg-white p-3 rounded-lg border border-amber-200">
                    <p className="text-sm text-center text-amber-700 mb-2">
                      +{pendingDoctors.length - 2} more doctor{pendingDoctors.length - 2 > 1 ? 's' : ''} waiting for approval
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full border-amber-300 text-amber-700 hover:bg-amber-50"
                      onClick={() => setCurrentScreen('consultations')}
                    >
                      📋 View All {pendingDoctors.length} Pending Requests
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  // Other screens - simplified
  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return renderDashboard();
      
      case 'add-patient':
      case 'edit-patient':
        return (
          <PatientForm
            userRole={userRole}
            editingPatientId={editingPatientId}
            patients={patients}
            patientForm={patientForm}
            onFormChange={handleFormChange}
            onCheckboxChange={handleCheckboxChange}
            onBooleanChange={handleBooleanChange}
            onSave={handleSavePatient}
            onBack={handleBackToClients}
          />
        );
      
      case 'patient-nutrition':
        const patient = viewingPatientId === 'client-1' 
          ? clientProfile 
          : patients.find(p => p.id === viewingPatientId);
        return patient ? (
          <PatientNutrition
            patient={patient}
            onBack={handleBackToClients}
            onSave={handleSaveNutrition}
            readOnly={userRole === 'client'}
          />
        ) : null;
      
      case 'smart-queue':
        // Admin view - show full dashboard
        if (userRole === 'admin') {
          return <SmartQueueDashboard />;
        }
        // Dietitian view - show their own queue panel
        if (userRole === 'dietitian') {
          return <DoctorQueuePanel doctorId="doc1" doctorName="Dr. Priya Sharma" />;
        }
        // Client view - show patient queue status
        if (userRole === 'client') {
          return <PatientQueueStatus patientId="p1" patientName="Arjun Patel" />;
        }
        return null;
      
      case 'doctor-queue':
        // Direct access to doctor queue panel
        return <DoctorQueuePanel doctorId="doc1" doctorName="Dr. Priya Sharma" />;
      
      case 'patient-queue':
        // Direct access to patient queue status
        return <PatientQueueStatus patientId="p1" patientName="Arjun Patel" />;
      
      case 'clients':
        return (userRole === 'admin' || userRole === 'dietitian') ? (
          <div className="p-4 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl text-green-800">
                {userRole === 'admin' ? 'Patient Management' : 'Client Management'}
              </h1>
              <Button className="bg-primary" onClick={handleAddPatient}>
                <Plus className="h-4 w-4 mr-2" />
                Add {userRole === 'admin' ? 'Patient' : 'Client'}
              </Button>
            </div>
            
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input 
                placeholder={`Search ${userRole === 'admin' ? 'patients' : 'clients'}...`} 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
              <span>Total {userRole === 'admin' ? 'Patients' : 'Clients'}: {patients.length}</span>
              {userRole === 'dietitian' && (
                <div className="flex items-center space-x-2">
                  <span className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded">
                    {patients.filter(p => p.addedBy === 'admin').length} admin-added
                  </span>
                  <span className="text-xs bg-green-50 text-green-600 px-2 py-1 rounded">
                    {patients.filter(p => p.addedBy === 'dietitian').length} my patients
                  </span>
                </div>
              )}
            </div>
            
            <div className="space-y-3">
              {(() => {
                const filteredPatients = patients.filter(patient =>
                  patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  patient.locality.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  patient.occupation.toLowerCase().includes(searchQuery.toLowerCase())
                );
                
                return filteredPatients.length === 0 ? (
                <Card className="shadow-md">
                  <CardContent className="p-8 text-center">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg text-gray-600 mb-2">No {userRole === 'admin' ? 'patients' : 'clients'} yet</h3>
                    <p className="text-sm text-gray-500 mb-4">Add your first {userRole === 'admin' ? 'patient' : 'client'} to get started</p>
                    <Button onClick={handleAddPatient} className="bg-primary">
                      <Plus className="h-4 w-4 mr-2" />
                      Add {userRole === 'admin' ? 'Patient' : 'Client'}
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                filteredPatients.map((patient) => (
                  <Card key={patient.id} className="shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3 flex-1">
                          <div className="h-12 w-12 bg-primary text-white rounded-full flex items-center justify-center">
                            {patient.name.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-medium">{patient.name}</h3>
                            <p className="text-sm text-gray-600">
                              {patient.age} years • {patient.gender} • {patient.locality}
                            </p>
                            <div className="flex items-center space-x-2 mt-1">
                              <Badge variant="outline" className="text-xs">
                                {patient.prakruti.length > 0 ? patient.prakruti.join('-') : 'Assessment Pending'}
                              </Badge>
                              <Badge variant="outline" className={`text-xs ${patient.status === 'active' ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-600'}`}>
                                {patient.status.charAt(0).toUpperCase() + patient.status.slice(1)}
                              </Badge>
                              {patient.addedBy === 'admin' && userRole === 'dietitian' && (
                                <Badge variant="outline" className="text-xs bg-blue-50 text-blue-600">
                                  Admin Added
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="text-right mr-3">
                            <p className="text-xs text-gray-500">
                              Added: {patient.dateAdded.toLocaleDateString()}
                            </p>
                            <p className="text-xs text-gray-500">
                              {patient.occupation}
                            </p>
                            <p className="text-xs text-gray-400">
                              by {patient.addedBy === 'admin' ? 'Admin' : 'Dietitian'}
                            </p>
                          </div>
                          {userRole === 'dietitian' && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewPatientNutrition(patient.id)}
                                className="h-8 w-8 p-0 text-green-600 hover:bg-green-50"
                                title="View nutrition & prescription"
                              >
                                <Activity className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEditPatient(patient.id)}
                                className="h-8 w-8 p-0 text-blue-600 hover:bg-blue-50"
                                title="Edit patient details"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                          {userRole === 'admin' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditPatient(patient.id)}
                              className="h-8 w-8 p-0 text-green-600 hover:bg-green-50"
                              title="View/Edit patient details"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                      {patient.mainComplaint && (
                        <div className="mt-3 p-2 bg-amber-50 rounded-lg">
                          <p className="text-xs text-amber-800">
                            <strong>Main Complaint:</strong> {patient.mainComplaint}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              );
              })()}
            </div>
          </div>
        ) : null;

      case 'my-profile':
        return userRole === 'client' ? (
          <div className="p-4 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl text-green-800">My Profile</h1>
              <Button 
                className="bg-primary" 
                onClick={() => {
                  setViewingPatientId('client-1');
                  setCurrentScreen('patient-nutrition');
                }}
              >
                <Activity className="h-4 w-4 mr-2" />
                View Nutrition Plan
              </Button>
            </div>
            
            {/* Client Profile Card */}
            <Card className="shadow-md">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="h-16 w-16 bg-primary text-white rounded-full flex items-center justify-center">
                      {clientProfile.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium">{clientProfile.name}</h3>
                      <p className="text-sm text-gray-600">
                        {clientProfile.age} years • {clientProfile.gender} • {clientProfile.locality}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">{clientProfile.occupation}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="outline" className="text-xs">
                          {clientProfile.prakruti.join('-')} Constitution
                        </Badge>
                        <Badge variant="outline" className="text-xs bg-green-50 text-green-700">
                          Active Plan
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Main Complaint */}
                <div className="mt-4 p-3 bg-amber-50 rounded-lg">
                  <p className="text-sm text-amber-800">
                    <strong>Current Focus:</strong> {clientProfile.mainComplaint}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Health Summary */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="text-green-800">Health Overview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm text-gray-600">Blood Pressure</Label>
                    <p className="text-lg">{clientProfile.bloodPressure}</p>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm text-gray-600">Pulse</Label>
                    <p className="text-lg">{clientProfile.pulse} bpm</p>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm text-gray-600">Activity Level</Label>
                    <p className="text-lg capitalize">{clientProfile.activityLevel}</p>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm text-gray-600">Dietary Preference</Label>
                    <p className="text-lg capitalize">{clientProfile.dietaryPreference}</p>
                  </div>
                </div>
                
                {clientProfile.allergies && (
                  <div className="mt-4 p-3 bg-red-50 rounded-lg">
                    <Label className="text-sm text-red-700 font-medium">Allergies</Label>
                    <p className="text-sm text-red-600 mt-1">{clientProfile.allergies}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Current Prescription Preview */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="text-green-800">Current Ayurvedic Plan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <Label className="text-sm font-medium text-amber-800">Constitutional Balance</Label>
                  <p className="text-sm text-amber-700 mt-1">
                    {clientProfile.ayurvedicPrescription?.doshaBalance}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium text-gray-800">Today's Herbs</Label>
                  {clientProfile.ayurvedicPrescription?.herbs.slice(0, 2).map((herb, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                      <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                        <Leaf className="h-4 w-4 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-800">{herb.name}</p>
                        <p className="text-sm text-gray-600">{herb.dosage} - {herb.timing}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    setViewingPatientId('client-1');
                    setCurrentScreen('patient-nutrition');
                  }}
                >
                  View Complete Plan
                </Button>
              </CardContent>
            </Card>

            {/* Next Consultation */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="text-green-800">Next Consultation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <p className="font-medium text-blue-800">Dr. Priya Sharma</p>
                    <p className="text-sm text-blue-600">Follow-up Consultation</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-blue-800">Tomorrow</p>
                    <p className="text-sm text-blue-600">2:00 PM</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null;

      case 'diet':
        return (
          <div className="p-4 space-y-6">
            <h1 className="text-2xl text-green-800">Diet Plans</h1>
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Today's Meals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {['Breakfast', 'Lunch', 'Dinner'].map((meal, index) => (
                    <div key={index} className="p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{meal}</h4>
                        <Button size="sm" variant="outline">
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'consultations':





        return (
          <div className="p-4 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl text-green-800">
                {userRole === 'client' ? 'Book Consultation' : 
                 userRole === 'dietitian' ? 'My Schedule' : 'Consultation Management'}
              </h1>
              {userRole !== 'client' && (
                <Button className="bg-primary">
                  <Plus className="h-4 w-4 mr-2" />
                  {userRole === 'dietitian' ? 'Block Time' : 'Add Slot'}
                </Button>
              )}
            </div>

            {/* Day Selector */}
            {userRole === 'client' && (
              <div className="flex space-x-2">
                <Button
                  variant={selectedDay === 'today' ? 'default' : 'outline'}
                  onClick={() => setSelectedDay('today')}
                  className={selectedDay === 'today' ? 'bg-primary' : ''}
                >
                  Today
                </Button>
                <Button
                  variant={selectedDay === 'tomorrow' ? 'default' : 'outline'}
                  onClick={() => setSelectedDay('tomorrow')}
                  className={selectedDay === 'tomorrow' ? 'bg-primary' : ''}
                >
                  Tomorrow
                </Button>
              </div>
            )}

            {userRole === 'client' ? (
              /* Client View - Available Doctors */
              <div className="space-y-4">
                <div className="text-sm text-gray-600 mb-4">
                  Available specialists for {selectedDay === 'today' ? 'today' : 'tomorrow'}
                </div>
                
                {approvedDoctors.map((doctor) => (
                  <Card key={doctor.id} className="shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <div className="h-16 w-16 bg-primary text-white rounded-full flex items-center justify-center">
                          {doctor.image}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-medium text-lg">{doctor.name}</h3>
                              <p className="text-sm text-gray-600">{doctor.specialty}</p>
                              <div className="flex items-center space-x-4 mt-1">
                                <span className="text-xs text-gray-500">{doctor.experience} experience</span>
                                <div className="flex items-center">
                                  <span className="text-xs text-amber-600">★ {doctor.rating}</span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-green-600">{doctor.consultationFee}</p>
                              <p className="text-xs text-gray-500">per session</p>
                            </div>
                          </div>
                          
                          {/* Available Time Slots */}
                          <div className="mt-4">
                            <p className="text-sm font-medium text-gray-700 mb-2">Available Slots</p>
                            <div className="grid grid-cols-3 gap-2">
                              {doctor.availability[selectedDay]
                                .filter(slot => slot.status === 'available')
                                .map((slot, index) => (
                                <Button
                                  key={index}
                                  variant="outline"
                                  size="sm"
                                  className="text-xs border-green-200 text-green-700 hover:bg-green-50"
                                  onClick={() => {
                                    alert(`Booking consultation with ${doctor.name} at ${slot.time}`);
                                  }}
                                >
                                  {slot.time}
                                </Button>
                              ))}
                            </div>
                            <p className="text-xs text-gray-500 mt-2">
                              {doctor.availability[selectedDay].filter(slot => slot.status === 'available').length} slots available
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : userRole === 'dietitian' ? (
              /* Dietitian View - My Schedule */
              <div className="space-y-4">
                <Card className="shadow-md bg-green-50 border-green-200">
                  <CardHeader>
                    <CardTitle className="text-green-800">Today's Appointments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mySchedule.length === 0 ? (
                        <div className="text-center py-8">
                          <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                          <h3 className="text-lg text-gray-600 mb-2">No appointments today</h3>
                          <p className="text-sm text-gray-500">Your schedule is clear for today</p>
                        </div>
                      ) : (
                        mySchedule.map((appointment) => (
                        <div key={appointment.id} className="bg-white p-4 rounded-lg border border-green-100 shadow-sm">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-3 flex-1">
                              <div className="h-12 w-12 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                                {appointment.patientName.split(' ').map(n => n[0]).join('')}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <h4 className="font-medium text-gray-900">{appointment.patientName}</h4>
                                    <p className="text-sm text-gray-600">{appointment.type}</p>
                                    <p className="text-xs text-gray-500 mt-1">{appointment.patientContact}</p>
                                    {appointment.notes && (
                                      <p className="text-xs text-gray-500 mt-2 bg-gray-50 p-2 rounded">
                                        📝 {appointment.notes}
                                      </p>
                                    )}
                                  </div>
                                  <div className="text-right ml-4">
                                    <p className="font-medium text-green-600">{appointment.time}</p>
                                    <p className="text-xs text-gray-500">{appointment.duration}</p>
                                    <Badge 
                                      variant="outline" 
                                      className={`text-xs mt-1 ${
                                        appointment.status === 'confirmed' 
                                          ? 'bg-green-50 text-green-700 border-green-200' 
                                          : 'bg-amber-50 text-amber-700 border-amber-200'
                                      }`}
                                    >
                                      {appointment.status}
                                    </Badge>
                                  </div>
                                </div>
                                
                                {/* Appointment Actions */}
                                <div className="flex items-center space-x-2 mt-3 pt-3 border-t border-gray-100">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="text-xs border-blue-200 text-blue-600 hover:bg-blue-50"
                                    onClick={() => handleRescheduleAppointment(appointment.id)}
                                  >
                                    <Calendar className="h-3 w-3 mr-1" />
                                    Reschedule
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="text-xs border-red-200 text-red-600 hover:bg-red-50"
                                    onClick={() => handleCancelAppointment(appointment.id)}
                                  >
                                    <ArrowLeft className="h-3 w-3 mr-1" />
                                    Cancel
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="text-xs border-green-200 text-green-600 hover:bg-green-50"
                                    onClick={() => {
                                      alert(`📞 Starting video call with ${appointment.patientName}...\n\nThis would launch the consultation interface.`);
                                    }}
                                  >
                                    <Activity className="h-3 w-3 mr-1" />
                                    Start Call
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Availability Management */}
                <Card className="shadow-md">
                  <CardHeader>
                    <CardTitle className="text-green-800">My Availability</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div>
                          <p className="font-medium">Available Slots Today</p>
                          <p className="text-sm text-gray-600">9:00 AM - 6:00 PM</p>
                        </div>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        {['9:00 AM', '10:30 AM', '12:00 PM', '2:30 PM', '4:00 PM', '5:30 PM'].map((time, index) => {
                          const isBooked = ['10:30 AM', '4:00 PM'].includes(time);
                          const isAvailable = !isBooked;
                          
                          return (
                            <div key={index} className="text-center">
                              <Button
                                variant="outline"
                                size="sm"
                                className={`w-full text-xs mb-2 ${
                                  isBooked
                                    ? 'bg-red-50 border-red-200 text-red-600'
                                    : 'bg-green-50 border-green-200 text-green-600 hover:bg-green-100'
                                }`}
                                onClick={() => {
                                  if (!isBooked) {
                                    handleToggleTimeSlot(time, 'available');
                                  }
                                }}
                                disabled={isBooked}
                              >
                                {time}
                              </Button>
                              <p className="text-xs text-gray-500 mb-1">
                                {isBooked ? 'Booked' : 'Available'}
                              </p>
                              {!isBooked && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-xs text-red-600 hover:bg-red-50 h-6 px-2"
                                  onClick={() => handleToggleTimeSlot(time, 'available')}
                                >
                                  Block Slot
                                </Button>
                              )}
                              {isBooked && (
                                <div className="flex flex-col space-y-1">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-xs text-blue-600 hover:bg-blue-50 h-6 px-2"
                                    onClick={() => {
                                      const appointment = mySchedule.find(apt => apt.time === time);
                                      if (appointment) {
                                        alert(`👤 Patient: ${appointment.patientName}\n📞 ${appointment.patientContact}\n📝 ${appointment.notes}`);
                                      }
                                    }}
                                  >
                                    View Details
                                  </Button>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              /* Admin View - Doctor Registration Management */
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Pending Requests</p>
                          <p className="text-xl">{pendingDoctors.length}</p>
                        </div>
                        <Bell className="h-5 w-5 text-amber-600" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">Approved Doctors</p>
                          <p className="text-xl">{approvedDoctors.length}</p>
                        </div>
                        <Stethoscope className="h-5 w-5 text-green-600" />
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Pending Doctor Registrations */}
                {pendingDoctors.length > 0 && (
                  <Card className="shadow-md bg-amber-50 border-amber-200">
                    <CardHeader>
                      <CardTitle className="text-amber-800 flex items-center">
                        <Bell className="h-5 w-5 mr-2" />
                        Pending Doctor Registrations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {pendingDoctors.map((doctor) => (
                          <div key={doctor.id} className="bg-white border border-amber-200 rounded-lg p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex items-start space-x-4">
                                <div className="h-16 w-16 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center font-medium">
                                  {doctor.name.split(' ').slice(1).map(n => n[0]).join('')}
                                </div>
                                <div>
                                  <h4 className="font-medium text-lg">{doctor.name}</h4>
                                  <p className="text-sm text-gray-600">{doctor.email}</p>
                                  <p className="text-sm text-gray-600">{doctor.specialty}</p>
                                  <p className="text-xs text-gray-500 mt-1">Experience: {doctor.experience}</p>
                                  <p className="text-xs text-gray-500">Qualifications: {doctor.qualifications}</p>
                                  <p className="text-xs text-gray-400 mt-2">
                                    Registered: {doctor.registrationDate.toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                              <div className="flex flex-col space-y-2">
                                <Button
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                  onClick={() => handleApproveDoctorRegistration(doctor.id)}
                                >
                                  <Shield className="h-4 w-4 mr-1" />
                                  Approve & Enable Slots
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-red-200 text-red-600 hover:bg-red-50"
                                  onClick={() => handleRejectDoctorRegistration(doctor.id)}
                                >
                                  Reject Registration
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Approved Doctors */}
                <Card className="shadow-md">
                  <CardHeader>
                    <CardTitle className="text-green-800">Approved Doctors & Availability</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {approvedDoctors.map((doctor) => (
                        <div key={doctor.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className="h-12 w-12 bg-primary text-white rounded-full flex items-center justify-center">
                                {doctor.image}
                              </div>
                              <div>
                                <h4 className="font-medium">{doctor.name}</h4>
                                <p className="text-sm text-gray-600">{doctor.specialty}</p>
                                <p className="text-xs text-gray-500">{doctor.consultationFee} per session</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge variant="outline" className="text-xs bg-green-50 text-green-700">
                                {doctor.availability.today.filter(slot => slot.status === 'available').length} slots available
                              </Badge>
                              <p className="text-xs text-gray-500 mt-1">★ {doctor.rating}</p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-6 gap-1">
                            {doctor.availability.today.map((slot, index) => (
                              <div
                                key={index}
                                className={`text-xs p-1 rounded text-center ${
                                  slot.status === 'available'
                                    ? 'bg-green-100 text-green-700'
                                    : 'bg-red-100 text-red-700'
                                }`}
                              >
                                {slot.time}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        );

      case 'reports':
        return (
          <div className="p-4 space-y-6">
            <h1 className="text-2xl text-green-800">Reports</h1>
            <div className="grid grid-cols-2 gap-4">
              <Card className="shadow-md">
                <CardContent className="p-4">
                  <p className="text-sm text-gray-600">Wellness Score</p>
                  <p className="text-xl">87%</p>
                </CardContent>
              </Card>
              <Card className="shadow-md">
                <CardContent className="p-4">
                  <p className="text-sm text-gray-600">Client Retention</p>
                  <p className="text-xl">94%</p>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="p-4 space-y-6">
            <h1 className="text-2xl text-green-800">Settings</h1>
            
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="text-green-800">Profile Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="h-16 w-16 bg-primary text-white rounded-full flex items-center justify-center">
                    {userRole === 'dietitian' ? 'PS' : 
                     userRole === 'admin' ? 'AD' : 'AP'}
                  </div>
                  <div>
                    <h3 className="font-medium">
                      {userRole === 'dietitian' ? 'Dr. Priya Sharma' : 
                       userRole === 'admin' ? 'Admin User' : 'Arjun Patel'}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {userRole === 'dietitian' ? 'Ayurvedic Specialist' : 
                       userRole === 'admin' ? 'Administrator' : 'Client'}
                    </p>
                    <Badge variant="outline" className="mt-1 text-xs">
                      {userRole.charAt(0).toUpperCase() + userRole.slice(1)} Account
                    </Badge>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  className="w-full border-red-200 text-red-600 hover:bg-red-50"
                  onClick={handleLogout}
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return renderDashboard();
    }
  };

  const getNavigation = () => {
    const navigation = [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'diet', label: 'Diet', icon: ClipboardList },
      { id: 'consultations', label: 'Consults', icon: Calendar },
      { id: 'reports', label: 'Reports', icon: BarChart },
      { id: 'settings', label: 'Settings', icon: SettingsIcon }
    ];

    // Add role-specific navigation
    if (userRole === 'client') {
      navigation.splice(1, 0, { id: 'my-profile', label: 'My Profile', icon: User });
      // Add Smart Queue for clients to track their consultation status
      navigation.splice(3, 0, { id: 'smart-queue', label: 'Queue', icon: Activity });
    } else if (userRole === 'admin' || userRole === 'dietitian') {
      navigation.splice(1, 0, { 
        id: 'clients', 
        label: userRole === 'admin' ? 'Patients' : 'Clients', 
        icon: Users 
      });
      // Add Smart Queue for admin (dashboard view) and dietitian (their queue panel)
      navigation.splice(3, 0, { id: 'smart-queue', label: 'Smart Queue', icon: Activity });
    }

    return navigation;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50">
      {currentScreen !== 'onboarding' && (
        <div className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-b z-10">
          <div className="flex items-center justify-between py-3 px-4">
            <div className="flex items-center space-x-2">
              <img 
                src={logoImage} 
                alt="Zyra Logo" 
                className="h-8 w-8 rounded-full object-cover"
              />
              <h1 className="text-lg text-green-800">Zyra</h1>
            </div>
            {userRole === 'admin' && pendingDoctors.length > 0 && (
              <div className="relative animate-pulse">
                <Bell className="h-6 w-6 text-amber-600" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-bounce">
                  {pendingDoctors.length}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      <div className={`pb-20 ${currentScreen !== 'onboarding' ? 'pt-16' : ''}`}>
        {renderScreen()}
      </div>

      {currentScreen !== 'onboarding' && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
          <div className="flex justify-around items-center py-2 px-4 max-w-md mx-auto">
            {getNavigation().map((item) => {
              const isActive = currentScreen === item.id;
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentScreen(item.id as any)}
                  className={`flex flex-col items-center space-y-1 h-auto py-2 px-3 ${
                    isActive ? 'text-primary bg-green-50' : 'text-gray-600'
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  <span className="text-xs">{item.label}</span>
                </Button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}