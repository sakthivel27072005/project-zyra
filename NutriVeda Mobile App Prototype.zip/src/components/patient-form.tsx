import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { 
  ArrowLeft,
  Stethoscope,
  Edit
} from 'lucide-react';

interface Patient {
  id: string;
  name: string;
  age: string;
  gender: string;
  locality: string;
  occupation: string;
  bloodPressure: string;
  pulse: string;
  mainComplaint: string;
  allergies: string;
  dietaryPreference: string;
  dietaryPreferenceOther: string;
  smoking: boolean;
  drinking: boolean;
  otherHabits: string;
  prakruti: string[];
  ritu: string;
  agni: string;
  bowelHabits: string;
  bowelHabitsOther: string;
  sleepPattern: string[];
  sleepPatternOther: string;
  activityLevel: string;
  dateAdded: Date;
  addedBy: 'admin' | 'dietitian';
  status: 'active' | 'inactive';
}

interface PatientFormData {
  name: string;
  age: string;
  gender: string;
  locality: string;
  occupation: string;
  bloodPressure: string;
  pulse: string;
  mainComplaint: string;
  allergies: string;
  dietaryPreference: string;
  dietaryPreferenceOther: string;
  smoking: boolean;
  drinking: boolean;
  otherHabits: string;
  prakruti: string[];
  ritu: string;
  agni: string;
  bowelHabits: string;
  bowelHabitsOther: string;
  sleepPattern: string[];
  sleepPatternOther: string;
  activityLevel: string;
}

interface PatientFormProps {
  userRole: string;
  editingPatientId: string | null;
  patients: Patient[];
  patientForm: PatientFormData;
  onFormChange: (field: string, value: string | string[]) => void;
  onCheckboxChange: (field: 'prakruti' | 'sleepPattern', value: string, checked: boolean) => void;
  onBooleanChange: (field: string, checked: boolean) => void;
  onSave: () => void;
  onBack: () => void;
}

export default function PatientForm({ 
  userRole, 
  editingPatientId, 
  patients, 
  patientForm, 
  onFormChange, 
  onCheckboxChange, 
  onBooleanChange, 
  onSave, 
  onBack 
}: PatientFormProps) {
  
  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center space-x-3 mb-6">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl text-green-800">
          {editingPatientId ? 'Edit Patient Details' : 'Health Assessment Form'}
        </h1>
      </div>

      {/* Patient Details */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-green-800">Patient Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Full Name *</Label>
              <Input
                value={patientForm.name}
                onChange={(e) => onFormChange('name', e.target.value)}
                placeholder="Enter patient name"
                className="border-green-200"
              />
            </div>

            <div className="space-y-2">
              <Label>Age *</Label>
              <Input
                type="number"
                value={patientForm.age}
                onChange={(e) => onFormChange('age', e.target.value)}
                placeholder="Enter age"
                className="border-green-200"
              />
            </div>

            <div className="space-y-3">
              <Label>Gender *</Label>
              <RadioGroup 
                value={patientForm.gender} 
                onValueChange={(value) => onFormChange('gender', value)}
                className="flex space-x-6"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="male" id="male" />
                  <Label htmlFor="male">Male</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="female" id="female" />
                  <Label htmlFor="female">Female</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="other" id="other" />
                  <Label htmlFor="other">Other</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label>Locality</Label>
              <Input
                value={patientForm.locality}
                onChange={(e) => onFormChange('locality', e.target.value)}
                placeholder="Enter locality"
                className="border-green-200"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label>Occupation</Label>
              <Input
                value={patientForm.occupation}
                onChange={(e) => onFormChange('occupation', e.target.value)}
                placeholder="Enter occupation"
                className="border-green-200"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vital Signs */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-green-800">Vital Signs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Blood Pressure</Label>
              <Input
                value={patientForm.bloodPressure}
                onChange={(e) => onFormChange('bloodPressure', e.target.value)}
                placeholder="e.g., 120/80"
                className="border-green-200"
              />
            </div>

            <div className="space-y-2">
              <Label>Pulse</Label>
              <Input
                value={patientForm.pulse}
                onChange={(e) => onFormChange('pulse', e.target.value)}
                placeholder="e.g., 72 bpm"
                className="border-green-200"
              />
            </div>

            {userRole === 'dietitian' && (
              <div className="space-y-2 md:col-span-2">
                <Label>Main Complaint</Label>
                <Textarea
                  value={patientForm.mainComplaint}
                  onChange={(e) => onFormChange('mainComplaint', e.target.value)}
                  placeholder="Describe the primary health concerns or symptoms..."
                  className="border-green-200"
                  rows={3}
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Allergy/Intolerance - Only for Dietitians */}
      {userRole === 'dietitian' && (
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-green-800">Allergy / Intolerance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label>Known Allergies</Label>
              <Textarea
                value={patientForm.allergies}
                onChange={(e) => onFormChange('allergies', e.target.value)}
                placeholder="List any known allergies (food, medication, environmental)... If none, write 'None'"
                className="border-green-200"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dietary Preference - Only for Dietitians */}
      {userRole === 'dietitian' && (
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-green-800">Dietary Preference</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <RadioGroup 
                value={patientForm.dietaryPreference} 
                onValueChange={(value) => onFormChange('dietaryPreference', value)}
                className="space-y-3"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="vegetarian" id="diet-vegetarian" />
                  <Label htmlFor="diet-vegetarian">Vegetarian</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="non-vegetarian" id="diet-non-vegetarian" />
                  <Label htmlFor="diet-non-vegetarian">Non-Vegetarian</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="vegan" id="diet-vegan" />
                  <Label htmlFor="diet-vegan">Vegan</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="other" id="diet-other" />
                  <Label htmlFor="diet-other">Other</Label>
                </div>
              </RadioGroup>
              
              {patientForm.dietaryPreference === 'other' && (
                <div className="space-y-2 mt-3">
                  <Label>Please specify</Label>
                  <Input
                    value={patientForm.dietaryPreferenceOther}
                    onChange={(e) => onFormChange('dietaryPreferenceOther', e.target.value)}
                    placeholder="Specify dietary preference"
                    className="border-green-200"
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lifestyle Habits - Only for Dietitians */}
      {userRole === 'dietitian' && (
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-green-800">Lifestyle Habits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label>Smoking</Label>
                  <div className="flex space-x-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="smoking-yes"
                        checked={patientForm.smoking}
                        onCheckedChange={(checked) => onBooleanChange('smoking', checked as boolean)}
                      />
                      <Label htmlFor="smoking-yes">Yes</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="smoking-no"
                        checked={!patientForm.smoking}
                        onCheckedChange={(checked) => onBooleanChange('smoking', !(checked as boolean))}
                      />
                      <Label htmlFor="smoking-no">No</Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Drinking Alcohol</Label>
                  <div className="flex space-x-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="drinking-yes"
                        checked={patientForm.drinking}
                        onCheckedChange={(checked) => onBooleanChange('drinking', checked as boolean)}
                      />
                      <Label htmlFor="drinking-yes">Yes</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="drinking-no"
                        checked={!patientForm.drinking}
                        onCheckedChange={(checked) => onBooleanChange('drinking', !(checked as boolean))}
                      />
                      <Label htmlFor="drinking-no">No</Label>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Other Habits</Label>
                <Input
                  value={patientForm.otherHabits}
                  onChange={(e) => onFormChange('otherHabits', e.target.value)}
                  placeholder="Any other lifestyle habits or activities"
                  className="border-green-200"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Ayurvedic Assessment - Only for Dietitians */}
      {userRole === 'dietitian' && (
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-green-800">Ayurvedic Assessment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Prakriti */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Prakriti</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {['Vata', 'Pitta', 'Kapha'].map((dosha) => (
                    <div key={dosha} className="flex items-center space-x-2">
                      <Checkbox
                        id={`prakriti-${dosha.toLowerCase()}`}
                        checked={patientForm.prakruti.includes(dosha)}
                        onCheckedChange={(checked) => 
                          onCheckboxChange('prakruti', dosha, checked as boolean)
                        }
                        className="border-gray-300"
                      />
                      <Label htmlFor={`prakriti-${dosha.toLowerCase()}`} className="text-sm">
                        {dosha}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Ritu (Current Season) */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Ritu (Current Season)</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { value: 'varsha', label: 'Varsha' },
                    { value: 'sharad', label: 'Sharad (Autumn)' },
                    { value: 'hemant', label: 'Hemant' },
                    { value: 'hemant-early', label: 'Hemant (Early Wn.)' },
                    { value: 'shishira', label: 'Shishira' },
                    { value: 'vasanta', label: 'Vasanta (Spring)' }
                  ].map((season) => (
                    <div key={season.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`ritu-${season.value}`}
                        checked={patientForm.ritu === season.value}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            onFormChange('ritu', season.value);
                          } else {
                            onFormChange('ritu', '');
                          }
                        }}
                        className="border-gray-300"
                      />
                      <Label htmlFor={`ritu-${season.value}`} className="text-sm">
                        {season.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Agni (Digestive Fire) */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Agni (Digestive Fire)</Label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: 'strong', label: 'Strong' },
                    { value: 'normal', label: 'Normal' }
                  ].map((agni) => (
                    <div key={agni.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`agni-${agni.value}`}
                        checked={patientForm.agni === agni.value}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            onFormChange('agni', agni.value);
                          } else {
                            onFormChange('agni', '');
                          }
                        }}
                        className="border-gray-300"
                      />
                      <Label htmlFor={`agni-${agni.value}`} className="text-sm">
                        {agni.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bowel Habits */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Bowel Habits</Label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: 'regular', label: 'Regular' },
                    { value: 'constipation', label: 'Constipation' }
                  ].map((habit) => (
                    <div key={habit.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`bowel-${habit.value}`}
                        checked={patientForm.bowelHabits === habit.value}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            onFormChange('bowelHabits', habit.value);
                          } else {
                            onFormChange('bowelHabits', '');
                          }
                        }}
                        className="border-gray-300"
                      />
                      <Label htmlFor={`bowel-${habit.value}`} className="text-sm">
                        {habit.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sleep Pattern */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Sleep Pattern</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { value: 'good', label: 'Good' },
                    { value: 'disturbed', label: 'Disturbed' },
                    { value: 'other', label: 'Other' }
                  ].map((pattern) => (
                    <div key={pattern.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`sleep-${pattern.value}`}
                        checked={patientForm.sleepPattern.includes(pattern.value)}
                        onCheckedChange={(checked) => 
                          onCheckboxChange('sleepPattern', pattern.value, checked as boolean)
                        }
                        className="border-gray-300"
                      />
                      <Label htmlFor={`sleep-${pattern.value}`} className="text-sm">
                        {pattern.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Activity Level */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Activity Level</Label>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { value: 'low', label: 'Low' },
                    { value: 'moderate', label: 'Moderate' },
                    { value: 'high', label: 'High' }
                  ].map((level) => (
                    <div key={level.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`activity-${level.value}`}
                        checked={patientForm.activityLevel === level.value}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            onFormChange('activityLevel', level.value);
                          } else {
                            onFormChange('activityLevel', '');
                          }
                        }}
                        className="border-gray-300"
                      />
                      <Label htmlFor={`activity-${level.value}`} className="text-sm">
                        {level.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Admin Note - Only for Admin Users */}
      {userRole === 'admin' && !editingPatientId && (
        <Card className="shadow-md bg-amber-50 border-amber-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="bg-amber-100 p-2 rounded-full">
                <Stethoscope className="h-4 w-4 text-amber-600" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-amber-800">Admin Registration</h4>
                <p className="text-xs text-amber-600 mt-1">
                  Ayurvedic constitutional assessment will be completed by the assigned dietitian during the first consultation.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Editing Note for Dietitians */}
      {userRole === 'dietitian' && editingPatientId && (() => {
        const editingPatient = patients.find(p => p.id === editingPatientId);
        return editingPatient?.addedBy === 'admin' ? (
          <Card className="shadow-md bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Edit className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-blue-800">Editing Admin-Added Patient</h4>
                  <p className="text-xs text-blue-600 mt-1">
                    You can now complete the Ayurvedic assessment and update any patient information as needed.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : null;
      })()}



      {/* Submit Button */}
      <div className="flex space-x-3 pb-4">
        <Button variant="outline" onClick={onBack} className="flex-1">
          Cancel
        </Button>
        <Button onClick={onSave} className="flex-1 bg-primary">
          {editingPatientId ? 'Update Patient' : 'Submit Assessment'}
        </Button>
      </div>
    </div>
  );
}