import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Calendar, Clock, User, Plus, Video, Phone, MessageSquare, Bell, Edit3 } from 'lucide-react';

interface Consultation {
  id: string;
  clientName: string;
  date: string;
  time: string;
  type: 'initial' | 'follow-up' | 'review';
  status: 'scheduled' | 'completed' | 'cancelled';
  mode: 'video' | 'phone' | 'in-person';
  notes?: string;
  followUpReminder?: boolean;
}

interface SessionNote {
  id: string;
  consultationId: string;
  symptoms: string;
  recommendations: string;
  nextSteps: string;
  createdAt: string;
}

export function Consultations() {
  const [selectedView, setSelectedView] = useState<'calendar' | 'notes'>('calendar');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedConsultation, setSelectedConsultation] = useState<Consultation | null>(null);

  const consultations: Consultation[] = [
    {
      id: '1',
      clientName: 'Priya Sharma',
      date: '2024-01-22',
      time: '10:00 AM',
      type: 'initial',
      status: 'scheduled',
      mode: 'video',
      followUpReminder: true
    },
    {
      id: '2',
      clientName: 'Rahul Mehta',
      date: '2024-01-22',
      time: '2:30 PM',
      type: 'follow-up',
      status: 'completed',
      mode: 'phone',
      notes: 'Client showing improvement in digestion',
      followUpReminder: true
    },
    {
      id: '3',
      clientName: 'Anjali Reddy',
      date: '2024-01-23',
      time: '11:00 AM',
      type: 'review',
      status: 'scheduled',
      mode: 'video',
      followUpReminder: false
    }
  ];

  const sessionNotes: SessionNote[] = [
    {
      id: '1',
      consultationId: '2',
      symptoms: 'Reduced acidity, better sleep patterns, mild joint stiffness in mornings',
      recommendations: 'Continue current diet plan, add warm sesame oil massage before bed, increase ginger tea intake',
      nextSteps: 'Follow-up in 2 weeks, monitor joint stiffness, adjust Vata-balancing foods',
      createdAt: '2024-01-22'
    }
  ];

  const [newConsultation, setNewConsultation] = useState({
    clientName: '',
    date: '',
    time: '',
    type: 'initial' as const,
    mode: 'video' as const,
    followUpReminder: true
  });

  const [newNote, setNewNote] = useState({
    symptoms: '',
    recommendations: '',
    nextSteps: ''
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'initial': return 'bg-purple-100 text-purple-800';
      case 'follow-up': return 'bg-blue-100 text-blue-800';
      case 'review': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'video': return <Video className="h-4 w-4" />;
      case 'phone': return <Phone className="h-4 w-4" />;
      case 'in-person': return <User className="h-4 w-4" />;
      default: return <Video className="h-4 w-4" />;
    }
  };

  if (selectedView === 'notes') {
    return (
      <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            <Button 
              variant={selectedView === 'calendar' ? 'default' : 'outline'} 
              onClick={() => setSelectedView('calendar')}
              className="bg-primary hover:bg-primary/90"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Calendar
            </Button>
            <Button 
              variant={selectedView === 'notes' ? 'default' : 'outline'} 
              onClick={() => setSelectedView('notes')}
              className="bg-primary hover:bg-primary/90"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Session Notes
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {sessionNotes.map((note) => {
            const consultation = consultations.find(c => c.id === note.consultationId);
            return (
              <Card key={note.id} className="shadow-md border-green-100">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-green-800">
                      {consultation?.clientName} - Session Notes
                    </CardTitle>
                    <Badge variant="outline">
                      {note.createdAt}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Symptoms & Observations</Label>
                    <p className="text-sm mt-1 p-3 bg-blue-50 rounded border-l-4 border-blue-200">
                      {note.symptoms}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Recommendations</Label>
                    <p className="text-sm mt-1 p-3 bg-green-50 rounded border-l-4 border-green-200">
                      {note.recommendations}
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Next Steps</Label>
                    <p className="text-sm mt-1 p-3 bg-orange-50 rounded border-l-4 border-orange-200">
                      {note.nextSteps}
                    </p>
                  </div>
                  <Button variant="outline" size="sm" className="border-green-200 hover:bg-green-50">
                    <Edit3 className="h-3 w-3 mr-2" />
                    Edit Notes
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex space-x-2">
          <Button 
            variant={selectedView === 'calendar' ? 'default' : 'outline'} 
            onClick={() => setSelectedView('calendar')}
            className="bg-primary hover:bg-primary/90"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Calendar
          </Button>
          <Button 
            variant={selectedView === 'notes' ? 'outline' : 'outline'} 
            onClick={() => setSelectedView('notes')}
            className="border-green-200 hover:bg-green-50"
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            Session Notes
          </Button>
        </div>
        <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-green-800">Schedule Consultation</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="client">Client</Label>
                <Select value={newConsultation.clientName} onValueChange={(value) => setNewConsultation(prev => ({ ...prev, clientName: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="priya-sharma">Priya Sharma</SelectItem>
                    <SelectItem value="rahul-mehta">Rahul Mehta</SelectItem>
                    <SelectItem value="anjali-reddy">Anjali Reddy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newConsultation.date}
                    onChange={(e) => setNewConsultation(prev => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <Input
                    id="time"
                    type="time"
                    value={newConsultation.time}
                    onChange={(e) => setNewConsultation(prev => ({ ...prev, time: e.target.value }))}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Consultation Type</Label>
                <Select value={newConsultation.type} onValueChange={(value: any) => setNewConsultation(prev => ({ ...prev, type: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="initial">Initial Consultation</SelectItem>
                    <SelectItem value="follow-up">Follow-up</SelectItem>
                    <SelectItem value="review">Diet Review</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="mode">Mode</Label>
                <Select value={newConsultation.mode} onValueChange={(value: any) => setNewConsultation(prev => ({ ...prev, mode: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="video">Video Call</SelectItem>
                    <SelectItem value="phone">Phone Call</SelectItem>
                    <SelectItem value="in-person">In-Person</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="reminder" 
                  checked={newConsultation.followUpReminder}
                  onCheckedChange={(checked) => setNewConsultation(prev => ({ ...prev, followUpReminder: checked }))}
                />
                <Label htmlFor="reminder" className="text-sm">Send follow-up reminder</Label>
              </div>
              <div className="flex space-x-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => setShowAddForm(false)}
                >
                  Schedule
                </Button>
                <Button variant="outline" onClick={() => setShowAddForm(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Today's Schedule */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Today's Schedule</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {consultations.filter(c => c.date === '2024-01-22').map((consultation) => (
              <div key={consultation.id} className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-green-100">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-primary text-white text-sm">
                    {consultation.clientName.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{consultation.clientName}</h4>
                    <div className="flex items-center space-x-1">
                      {getModeIcon(consultation.mode)}
                      <span className="text-xs text-gray-500">{consultation.time}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="outline" className={getTypeColor(consultation.type)}>
                      {consultation.type}
                    </Badge>
                    <Badge variant="outline" className={getStatusColor(consultation.status)}>
                      {consultation.status}
                    </Badge>
                    {consultation.followUpReminder && (
                      <Bell className="h-3 w-3 text-orange-500" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Consultations */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Upcoming Consultations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {consultations.filter(c => c.date > '2024-01-22').map((consultation) => (
              <div key={consultation.id} className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-secondary text-white text-sm">
                    {consultation.clientName.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{consultation.clientName}</h4>
                    <div className="flex items-center space-x-1">
                      {getModeIcon(consultation.mode)}
                      <span className="text-xs text-gray-500">{consultation.date} • {consultation.time}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="outline" className={getTypeColor(consultation.type)}>
                      {consultation.type}
                    </Badge>
                    {consultation.followUpReminder && (
                      <Bell className="h-3 w-3 text-orange-500" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Session Notes Quick Add */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Add Session Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="consultation-select">Select Consultation</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Choose completed consultation" />
              </SelectTrigger>
              <SelectContent>
                {consultations.filter(c => c.status === 'completed').map(consultation => (
                  <SelectItem key={consultation.id} value={consultation.id}>
                    {consultation.clientName} - {consultation.date}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="symptoms">Symptoms & Observations</Label>
            <Textarea
              id="symptoms"
              placeholder="Record client's symptoms and your observations..."
              value={newNote.symptoms}
              onChange={(e) => setNewNote(prev => ({ ...prev, symptoms: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="recommendations">Recommendations</Label>
            <Textarea
              id="recommendations"
              placeholder="Ayurvedic recommendations and treatments..."
              value={newNote.recommendations}
              onChange={(e) => setNewNote(prev => ({ ...prev, recommendations: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="next-steps">Next Steps</Label>
            <Textarea
              id="next-steps"
              placeholder="Follow-up actions and next consultation plans..."
              value={newNote.nextSteps}
              onChange={(e) => setNewNote(prev => ({ ...prev, nextSteps: e.target.value }))}
            />
          </div>
          <Button className="w-full bg-primary hover:bg-primary/90">
            Save Session Notes
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}