import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { User, Stethoscope, ArrowRight, Mail, Phone } from 'lucide-react';

interface OnboardingProps {
  onComplete: (userRole: string) => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [userRole, setUserRole] = useState('');
  const [loginData, setLoginData] = useState({
    email: '',
    mobile: '',
    loginMethod: 'email'
  });

  const handleRoleSelection = (role: string) => {
    setUserRole(role);
    setStep(2);
  };

  const handleLogin = () => {
    onComplete(userRole);
  };

  if (step === 1) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50 p-4 flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
          <div className="text-center mb-8">
            <div className="relative w-40 h-40 mx-auto mb-6 rounded-full overflow-hidden shadow-lg">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1705083649602-03c5fbae2e89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxheXVydmVkYSUyMGhlcmJzJTIwbmF0dXJhbCUyMHdlbGxuZXNzfGVufDF8fHx8MTc1ODg3NjQxOXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Ayurveda herbs and wellness"
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-3xl mb-2 text-green-800">NutriVeda</h1>
            <p className="text-green-600 mb-2">Modern Nutrition with Ancient Wisdom</p>
            <p className="text-sm text-gray-600">Personalized Ayurvedic diet plans for holistic wellness</p>
          </div>

          <Card className="w-full shadow-lg border-green-100">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-green-800">Choose Your Role</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                variant="outline"
                className="w-full h-16 flex items-center justify-between p-4 border-2 hover:border-primary hover:bg-green-50"
                onClick={() => handleRoleSelection('dietitian')}
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-primary/10 rounded-full">
                    <Stethoscope className="h-6 w-6 text-primary" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Ayurvedic Dietitian</div>
                    <div className="text-sm text-gray-500">Manage clients & create diet plans</div>
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </Button>

              <Button
                variant="outline"
                className="w-full h-16 flex items-center justify-between p-4 border-2 hover:border-primary hover:bg-green-50"
                onClick={() => handleRoleSelection('client')}
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-secondary/10 rounded-full">
                    <User className="h-6 w-6 text-secondary" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Client</div>
                    <div className="text-sm text-gray-500">Access your personalized diet plans</div>
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-gray-400" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-amber-50 p-4 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
        <div className="text-center mb-8">
          <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden shadow-md">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1657584942205-c34fec47404d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIweW9nYSUyMHdlbGxuZXNzJTIwaWxsdXN0cmF0aW9ufGVufDF8fHx8MTc1ODg3NjQyMnww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Meditation and wellness"
              className="w-full h-full object-cover"
            />
          </div>
          <h2 className="text-2xl mb-2 text-green-800">Welcome Back</h2>
          <p className="text-green-600">Sign in to continue your wellness journey</p>
        </div>

        <Card className="w-full shadow-lg border-green-100">
          <CardContent className="p-6 space-y-4">
            <RadioGroup 
              value={loginData.loginMethod} 
              onValueChange={(value) => setLoginData(prev => ({ ...prev, loginMethod: value }))}
              className="flex space-x-4 mb-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="email" id="email" />
                <Label htmlFor="email" className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span>Email</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="mobile" id="mobile" />
                <Label htmlFor="mobile" className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>Mobile</span>
                </Label>
              </div>
            </RadioGroup>

            {loginData.loginMethod === 'email' ? (
              <div className="space-y-2">
                <Label htmlFor="email-input">Email Address</Label>
                <Input
                  id="email-input"
                  type="email"
                  placeholder="Enter your email"
                  value={loginData.email}
                  onChange={(e) => setLoginData(prev => ({ ...prev, email: e.target.value }))}
                  className="border-green-200 focus:border-primary"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="mobile-input">Mobile Number</Label>
                <Input
                  id="mobile-input"
                  type="tel"
                  placeholder="Enter your mobile number"
                  value={loginData.mobile}
                  onChange={(e) => setLoginData(prev => ({ ...prev, mobile: e.target.value }))}
                  className="border-green-200 focus:border-primary"
                />
              </div>
            )}

            <Button 
              onClick={handleLogin}
              className="w-full bg-primary hover:bg-primary/90 text-white"
            >
              Continue
            </Button>

            <p className="text-xs text-center text-gray-500 mt-4">
              By continuing, you agree to our Terms of Service and Privacy Policy
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}