import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Calendar, Users, ClipboardList, Bell, TrendingUp, Clock, Heart, Leaf } from 'lucide-react';

interface DashboardProps {
  userRole: string;
}

export function Dashboard({ userRole }: DashboardProps) {
  const isDietitian = userRole === 'dietitian';

  const stats = isDietitian ? [
    { label: 'Active Clients', value: '24', icon: Users, color: 'text-blue-600' },
    { label: 'Consultations Today', value: '8', icon: Calendar, color: 'text-green-600' },
    { label: 'Pending Plans', value: '3', icon: ClipboardList, color: 'text-orange-600' },
    { label: 'This Month Revenue', value: '₹45,200', icon: TrendingUp, color: 'text-purple-600' }
  ] : [
    { label: 'Days on Plan', value: '12', icon: Calendar, color: 'text-blue-600' },
    { label: 'Wellness Score', value: '85%', icon: Heart, color: 'text-red-500' },
    { label: 'Dosha Balance', value: 'Pitta', icon: Leaf, color: 'text-green-600' },
    { label: 'Next Consultation', value: '2 days', icon: Clock, color: 'text-orange-600' }
  ];

  const notifications = isDietitian ? [
    { message: 'New client Priya S. registered', time: '2 min ago', type: 'new' },
    { message: 'Rahul M. completed weekly check-in', time: '1 hr ago', type: 'update' },
    { message: 'Diet plan review due for 3 clients', time: '3 hrs ago', type: 'reminder' }
  ] : [
    { message: 'Time for your morning meal - Breakfast', time: 'Now', type: 'meal' },
    { message: 'Weekly progress update ready', time: '1 hr ago', type: 'update' },
    { message: 'Consultation reminder: Tomorrow 3 PM', time: '2 hrs ago', type: 'reminder' }
  ];

  const upcomingEvents = isDietitian ? [
    { client: 'Anjali R.', time: '10:00 AM', type: 'Initial Consultation', avatar: 'AR' },
    { client: 'Vikash K.', time: '2:30 PM', type: 'Follow-up', avatar: 'VK' },
    { client: 'Meera P.', time: '4:00 PM', type: 'Diet Review', avatar: 'MP' }
  ] : [
    { title: 'Morning Meditation', time: '6:00 AM', type: 'Wellness Activity' },
    { title: 'Dr. Sharma Consultation', time: '3:00 PM', type: 'Consultation' },
    { title: 'Evening Walk', time: '6:30 PM', type: 'Exercise' }
  ];

  return (
    <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl text-green-800">
            Good morning, {isDietitian ? 'Dr. Priya' : 'Arjun'}! 🌞
          </h1>
          <p className="text-green-600">
            {isDietitian ? 'Ready to help clients achieve wellness today?' : 'Let\'s continue your wellness journey'}
          </p>
        </div>
        <div className="relative">
          <Bell className="h-6 w-6 text-green-700" />
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">3</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, index) => (
          <Card key={index} className="shadow-md border-green-100">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-xl">{stat.value}</p>
                </div>
                <div className={`p-2 rounded-full bg-gray-100 ${stat.color}`}>
                  <stat.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Notifications */}
      <Card className="shadow-md border-green-100">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <Bell className="h-5 w-5" />
            <span>Recent Notifications</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {notifications.map((notification, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
              <div className="flex-1">
                <p className="text-sm">{notification.message}</p>
                <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
              </div>
            </div>
          ))}
          <Button variant="ghost" className="w-full text-primary hover:bg-green-50">
            View All Notifications
          </Button>
        </CardContent>
      </Card>

      {/* Today's Schedule */}
      <Card className="shadow-md border-green-100">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <Calendar className="h-5 w-5" />
            <span>{isDietitian ? 'Today\'s Consultations' : 'Today\'s Schedule'}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {upcomingEvents.map((event, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-green-100">
              {isDietitian ? (
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-primary text-white text-sm">
                    {event.avatar}
                  </AvatarFallback>
                </Avatar>
              ) : (
                <div className="w-10 h-10 bg-secondary/10 rounded-full flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-secondary" />
                </div>
              )}
              <div className="flex-1">
                <p className="text-sm">{isDietitian ? event.client : event.title}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="secondary" className="text-xs">
                    {event.type}
                  </Badge>
                  <span className="text-xs text-gray-500">{event.time}</span>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="shadow-md border-green-100">
        <CardHeader className="pb-3">
          <CardTitle className="text-green-800">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {isDietitian ? (
              <>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <Users className="h-4 w-4" />
                  <span className="text-xs">Add Client</span>
                </Button>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <ClipboardList className="h-4 w-4" />
                  <span className="text-xs">Create Plan</span>
                </Button>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <Calendar className="h-4 w-4" />
                  <span className="text-xs">Schedule</span>
                </Button>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-xs">Reports</span>
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <Heart className="h-4 w-4" />
                  <span className="text-xs">Log Symptoms</span>
                </Button>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <ClipboardList className="h-4 w-4" />
                  <span className="text-xs">Meal Plan</span>
                </Button>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <Calendar className="h-4 w-4" />
                  <span className="text-xs">Book Session</span>
                </Button>
                <Button variant="outline" className="h-12 flex flex-col space-y-1 border-green-200 hover:bg-green-50">
                  <Leaf className="h-4 w-4" />
                  <span className="text-xs">Dosha Test</span>
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}