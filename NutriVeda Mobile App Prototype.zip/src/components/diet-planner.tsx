import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Plus, Search, Download, Share, Sunrise, Sun, Sunset, Moon, Info } from 'lucide-react';

interface Food {
  id: string;
  name: string;
  category: string;
  rasa: string;
  virya: string;
  vipaka: string;
  guna: string[];
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  doshaEffect: {
    vata: 'increase' | 'decrease' | 'neutral';
    pitta: 'increase' | 'decrease' | 'neutral';
    kapha: 'increase' | 'decrease' | 'neutral';
  };
}

interface Meal {
  id: string;
  time: string;
  foods: Food[];
  totalCalories: number;
  notes?: string;
}

export function DietPlanner() {
  const [selectedMealSlot, setSelectedMealSlot] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClient, setSelectedClient] = useState('priya-sharma');

  const ayurvedicFoods: Food[] = [
    {
      id: '1',
      name: 'Quinoa Khichdi',
      category: 'Grains',
      rasa: 'Sweet',
      virya: 'Cooling',
      vipaka: 'Sweet',
      guna: ['Light', 'Dry'],
      calories: 180,
      protein: 6,
      carbs: 32,
      fat: 3,
      doshaEffect: { vata: 'neutral', pitta: 'decrease', kapha: 'neutral' }
    },
    {
      id: '2',
      name: 'Steamed Vegetables with Ghee',
      category: 'Vegetables',
      rasa: 'Sweet, Bitter',
      virya: 'Cooling',
      vipaka: 'Sweet',
      guna: ['Light', 'Moist'],
      calories: 120,
      protein: 3,
      carbs: 15,
      fat: 6,
      doshaEffect: { vata: 'decrease', pitta: 'decrease', kapha: 'neutral' }
    },
    {
      id: '3',
      name: 'Herbal Buttermilk',
      category: 'Beverages',
      rasa: 'Sour, Astringent',
      virya: 'Cooling',
      vipaka: 'Sweet',
      guna: ['Light', 'Liquid'],
      calories: 60,
      protein: 2,
      carbs: 4,
      fat: 3,
      doshaEffect: { vata: 'neutral', pitta: 'decrease', kapha: 'decrease' }
    }
  ];

  const [meals, setMeals] = useState<Meal[]>([
    {
      id: 'breakfast',
      time: '7:00 AM',
      foods: [],
      totalCalories: 0,
      notes: 'Start with warm water and lemon'
    },
    {
      id: 'lunch',
      time: '12:30 PM',
      foods: [ayurvedicFoods[0], ayurvedicFoods[1]],
      totalCalories: 300,
      notes: 'Main meal of the day'
    },
    {
      id: 'snack',
      time: '4:00 PM',
      foods: [ayurvedicFoods[2]],
      totalCalories: 60,
      notes: 'Light evening snack'
    },
    {
      id: 'dinner',
      time: '7:00 PM',
      foods: [],
      totalCalories: 0,
      notes: 'Light and early dinner'
    }
  ]);

  const getMealIcon = (mealId: string) => {
    switch (mealId) {
      case 'breakfast': return <Sunrise className="h-5 w-5 text-orange-500" />;
      case 'lunch': return <Sun className="h-5 w-5 text-yellow-500" />;
      case 'snack': return <Sunset className="h-5 w-5 text-orange-400" />;
      case 'dinner': return <Moon className="h-5 w-5 text-blue-500" />;
      default: return <Sun className="h-5 w-5" />;
    }
  };

  const getDoshaColor = (effect: string) => {
    switch (effect) {
      case 'increase': return 'text-red-600';
      case 'decrease': return 'text-green-600';
      case 'neutral': return 'text-gray-600';
      default: return 'text-gray-600';
    }
  };

  const getDoshaSymbol = (effect: string) => {
    switch (effect) {
      case 'increase': return '↑';
      case 'decrease': return '↓';
      case 'neutral': return '=';
      default: return '=';
    }
  };

  const addFoodToMeal = (mealId: string, food: Food) => {
    setMeals(prev => prev.map(meal => 
      meal.id === mealId 
        ? {
            ...meal,
            foods: [...meal.foods, food],
            totalCalories: meal.totalCalories + food.calories
          }
        : meal
    ));
    setSelectedMealSlot(null);
  };

  const totalDayCalories = meals.reduce((sum, meal) => sum + meal.totalCalories, 0);
  const totalProtein = meals.reduce((sum, meal) => 
    sum + meal.foods.reduce((mealSum, food) => mealSum + food.protein, 0), 0
  );
  const totalCarbs = meals.reduce((sum, meal) => 
    sum + meal.foods.reduce((mealSum, food) => mealSum + food.carbs, 0), 0
  );
  const totalFat = meals.reduce((sum, meal) => 
    sum + meal.foods.reduce((mealSum, food) => mealSum + food.fat, 0), 0
  );

  return (
    <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl text-green-800">Diet & Nutrition Planner</h1>
          <p className="text-green-600">Creating personalized Ayurvedic meal plans</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="border-green-200 hover:bg-green-50">
            <Share className="h-4 w-4 mr-2" />
            Share
          </Button>
          <Button className="bg-primary hover:bg-primary/90">
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      {/* Client Selection */}
      <Card className="shadow-md border-green-100">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm text-gray-600">Creating plan for:</Label>
              <Select value={selectedClient} onValueChange={setSelectedClient}>
                <SelectTrigger className="w-48 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="priya-sharma">Priya Sharma (Pitta-Vata)</SelectItem>
                  <SelectItem value="rahul-mehta">Rahul Mehta (Kapha-Pitta)</SelectItem>
                  <SelectItem value="anjali-reddy">Anjali Reddy (Vata-Pitta)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Today's Target</p>
              <p className="text-lg">1,800 calories</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Nutrition Summary */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Daily Nutrition Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl text-primary">{totalDayCalories}</p>
              <p className="text-sm text-gray-600">Calories</p>
            </div>
            <div>
              <p className="text-2xl text-blue-600">{totalProtein}g</p>
              <p className="text-sm text-gray-600">Protein</p>
            </div>
            <div>
              <p className="text-2xl text-orange-600">{totalCarbs}g</p>
              <p className="text-sm text-gray-600">Carbs</p>
            </div>
            <div>
              <p className="text-2xl text-purple-600">{totalFat}g</p>
              <p className="text-sm text-gray-600">Fat</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Meal Slots */}
      <div className="space-y-4">
        {meals.map((meal) => (
          <Card key={meal.id} className="shadow-md border-green-100">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {getMealIcon(meal.id)}
                  <CardTitle className="text-green-800 capitalize">{meal.id}</CardTitle>
                  <span className="text-sm text-gray-500">{meal.time}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-xs">
                    {meal.totalCalories} cal
                  </Badge>
                  <Dialog open={selectedMealSlot === meal.id} onOpenChange={(open) => setSelectedMealSlot(open ? meal.id : null)}>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline" className="border-green-200 hover:bg-green-50">
                        <Plus className="h-3 w-3 mr-1" />
                        Add Food
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle className="text-green-800">Add Food to {meal.id}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="relative">
                          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                          <Input
                            placeholder="Search Ayurvedic foods..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10"
                          />
                        </div>
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {ayurvedicFoods
                            .filter(food => food.name.toLowerCase().includes(searchQuery.toLowerCase()))
                            .map((food) => (
                            <div 
                              key={food.id} 
                              className="p-3 border border-green-100 rounded-lg cursor-pointer hover:bg-green-50"
                              onClick={() => addFoodToMeal(meal.id, food)}
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h4 className="font-medium">{food.name}</h4>
                                  <p className="text-xs text-gray-600 mt-1">
                                    {food.calories} cal • {food.rasa} • {food.virya}
                                  </p>
                                  <div className="flex space-x-2 mt-1">
                                    <span className={`text-xs ${getDoshaColor(food.doshaEffect.vata)}`}>
                                      V{getDoshaSymbol(food.doshaEffect.vata)}
                                    </span>
                                    <span className={`text-xs ${getDoshaColor(food.doshaEffect.pitta)}`}>
                                      P{getDoshaSymbol(food.doshaEffect.pitta)}
                                    </span>
                                    <span className={`text-xs ${getDoshaColor(food.doshaEffect.kapha)}`}>
                                      K{getDoshaSymbol(food.doshaEffect.kapha)}
                                    </span>
                                  </div>
                                </div>
                                <Badge variant="outline" className="text-xs">
                                  {food.category}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {meal.foods.length > 0 ? (
                <div className="space-y-2">
                  {meal.foods.map((food, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-green-50 rounded">
                      <div>
                        <p className="text-sm font-medium">{food.name}</p>
                        <p className="text-xs text-gray-600">
                          {food.calories} cal • {food.rasa} • {food.virya}
                        </p>
                      </div>
                      <div className="flex items-center space-x-1">
                        <span className={`text-xs ${getDoshaColor(food.doshaEffect.vata)}`}>
                          V{getDoshaSymbol(food.doshaEffect.vata)}
                        </span>
                        <span className={`text-xs ${getDoshaColor(food.doshaEffect.pitta)}`}>
                          P{getDoshaSymbol(food.doshaEffect.pitta)}
                        </span>
                        <span className={`text-xs ${getDoshaColor(food.doshaEffect.kapha)}`}>
                          K{getDoshaSymbol(food.doshaEffect.kapha)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500">
                  <p className="text-sm">No foods added yet</p>
                </div>
              )}
              {meal.notes && (
                <div className="mt-3 p-2 bg-blue-50 rounded border-l-4 border-blue-200">
                  <div className="flex items-start space-x-2">
                    <Info className="h-4 w-4 text-blue-600 mt-0.5" />
                    <p className="text-sm text-blue-800">{meal.notes}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Ayurvedic Properties Legend */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Ayurvedic Properties Guide</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">Dosha Effects:</h4>
              <div className="space-y-1">
                <p><span className="text-green-600">↓</span> Decreases dosha</p>
                <p><span className="text-red-600">↑</span> Increases dosha</p>
                <p><span className="text-gray-600">=</span> Neutral effect</p>
              </div>
            </div>
            <div>
              <h4 className="font-medium mb-2">Six Tastes (Rasa):</h4>
              <div className="space-y-1 text-xs">
                <p>Sweet, Sour, Salty, Pungent, Bitter, Astringent</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}