import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { 
  ArrowLeft,
  Save,
  Edit,
  Activity,
  Zap,
  Droplets,
  Wheat,
  Target,
  TrendingUp,
  Pill,
  Clock,
  Info,
  Leaf,
  User,
  Plus
} from 'lucide-react';

interface Patient {
  id: string;
  name: string;
  age: string;
  gender: string;
  prakruti: string[];
  nutrition?: {
    calories: { current: number; target: number };
    protein: { current: number; target: number };
    carbs: { current: number; target: number };
    fats: { current: number; target: number };
    micronutrients: {
      vitaminA: number;
      vitaminC: number;
      vitaminD: number;
      iron: number;
      calcium: number;
      zinc: number;
      magnesium: number;
      folate: number;
    };
  };
  ayurvedicPrescription?: {
    recommendations: string[];
    doshaBalance: string;
    herbs: { name: string; dosage: string; timing: string }[];
  };
}

interface PatientNutritionProps {
  patient: Patient;
  onBack: () => void;
  onSave: (nutritionData: any) => void;
  readOnly?: boolean;
}

export default function PatientNutrition({ patient, onBack, onSave, readOnly = false }: PatientNutritionProps) {
  const [editingNutrition, setEditingNutrition] = useState(false);
  const [nutritionForm, setNutritionForm] = useState({
    calories: patient.nutrition?.calories || { current: 0, target: 2000 },
    protein: patient.nutrition?.protein || { current: 0, target: 50 },
    carbs: patient.nutrition?.carbs || { current: 0, target: 200 },
    fats: patient.nutrition?.fats || { current: 0, target: 65 },
    micronutrients: patient.nutrition?.micronutrients || {
      vitaminA: 0, vitaminC: 0, vitaminD: 0, iron: 0,
      calcium: 0, zinc: 0, magnesium: 0, folate: 0
    },
    doshaBalance: patient.ayurvedicPrescription?.doshaBalance || '',
    recommendations: patient.ayurvedicPrescription?.recommendations || [],
    herbs: patient.ayurvedicPrescription?.herbs || []
  });

  const macroNutrients = [
    {
      name: 'Calories',
      current: patient.nutrition?.calories.current || 0,
      target: patient.nutrition?.calories.target || 2000,
      unit: 'kcal',
      color: 'bg-green-500',
      icon: Zap
    },
    {
      name: 'Protein',
      current: patient.nutrition?.protein.current || 0,
      target: patient.nutrition?.protein.target || 50,
      unit: 'g',
      color: 'bg-orange-500',
      icon: Activity
    },
    {
      name: 'Carbs',
      current: patient.nutrition?.carbs.current || 0,
      target: patient.nutrition?.carbs.target || 200,
      unit: 'g',
      color: 'bg-blue-500',
      icon: Wheat
    },
    {
      name: 'Fats',
      current: patient.nutrition?.fats.current || 0,
      target: patient.nutrition?.fats.target || 65,
      unit: 'g',
      color: 'bg-yellow-500',
      icon: Droplets
    }
  ];

  const microNutrients = [
    { name: 'Vitamin A', value: patient.nutrition?.micronutrients.vitaminA || 0, unit: '%' },
    { name: 'Vitamin C', value: patient.nutrition?.micronutrients.vitaminC || 0, unit: '%' },
    { name: 'Vitamin D', value: patient.nutrition?.micronutrients.vitaminD || 0, unit: '%' },
    { name: 'Iron', value: patient.nutrition?.micronutrients.iron || 0, unit: '%' },
    { name: 'Calcium', value: patient.nutrition?.micronutrients.calcium || 0, unit: '%' },
    { name: 'Zinc', value: patient.nutrition?.micronutrients.zinc || 0, unit: '%' },
    { name: 'Magnesium', value: patient.nutrition?.micronutrients.magnesium || 0, unit: '%' },
    { name: 'Folate', value: patient.nutrition?.micronutrients.folate || 0, unit: '%' }
  ];

  const handleMacroChange = (nutrient: string, type: 'current' | 'target', value: number) => {
    setNutritionForm(prev => ({
      ...prev,
      [nutrient]: {
        ...prev[nutrient as keyof typeof prev],
        [type]: value
      }
    }));
  };

  const handleMicroChange = (nutrient: string, value: number) => {
    setNutritionForm(prev => ({
      ...prev,
      micronutrients: {
        ...prev.micronutrients,
        [nutrient]: value
      }
    }));
  };

  const handleHerbChange = (index: number, field: string, value: string) => {
    setNutritionForm(prev => ({
      ...prev,
      herbs: prev.herbs.map((herb, i) => 
        i === index ? { ...herb, [field]: value } : herb
      )
    }));
  };

  const addHerb = () => {
    setNutritionForm(prev => ({
      ...prev,
      herbs: [...prev.herbs, { name: '', dosage: '', timing: '' }]
    }));
  };

  const removeHerb = (index: number) => {
    setNutritionForm(prev => ({
      ...prev,
      herbs: prev.herbs.filter((_, i) => i !== index)
    }));
  };

  const addRecommendation = () => {
    setNutritionForm(prev => ({
      ...prev,
      recommendations: [...prev.recommendations, '']
    }));
  };

  const updateRecommendation = (index: number, value: string) => {
    setNutritionForm(prev => ({
      ...prev,
      recommendations: prev.recommendations.map((rec, i) => 
        i === index ? value : rec
      )
    }));
  };

  const removeRecommendation = (index: number) => {
    setNutritionForm(prev => ({
      ...prev,
      recommendations: prev.recommendations.filter((_, i) => i !== index)
    }));
  };

  const saveNutritionChanges = () => {
    const nutritionData = {
      nutrition: {
        calories: nutritionForm.calories,
        protein: nutritionForm.protein,
        carbs: nutritionForm.carbs,
        fats: nutritionForm.fats,
        micronutrients: nutritionForm.micronutrients
      },
      ayurvedicPrescription: {
        doshaBalance: nutritionForm.doshaBalance,
        recommendations: nutritionForm.recommendations.filter(r => r.trim() !== ''),
        herbs: nutritionForm.herbs.filter(h => h.name.trim() !== '')
      }
    };
    
    onSave(nutritionData);
    setEditingNutrition(false);
    alert('Nutrition plan updated successfully!');
  };

  return (
    <div className="p-4 space-y-6 pb-24">
      {/* Header */}
      <div className="flex items-center space-x-3 mb-6">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex items-center space-x-3">
          <Leaf className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-xl text-green-800">NutriVeda</h1>
            <p className="text-sm text-green-600">Nutrition & Wellness</p>
          </div>
        </div>
        <div className="flex-1"></div>
        <div className="h-10 w-10 bg-primary text-white rounded-full flex items-center justify-center">
          <User className="h-5 w-5" />
        </div>
      </div>

      {/* Patient Info Header */}
      <Card className="shadow-md bg-gradient-to-r from-green-50 to-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="h-16 w-16 bg-primary text-white rounded-full flex items-center justify-center">
              {patient.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-medium text-gray-800">{patient.name}</h2>
              <p className="text-sm text-gray-600">{patient.age} years • {patient.gender}</p>
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  {patient.prakruti.join('-') || 'Assessment Pending'}
                </Badge>
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700">
                  Active Plan
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Macro Nutrients Section */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-green-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Target className="h-5 w-5" />
              <span>Macro Nutrients</span>
            </div>
            {!editingNutrition && !readOnly && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setEditingNutrition(true)}
                className="text-blue-600 border-blue-200 hover:bg-blue-50"
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!editingNutrition ? (
            <div className="grid grid-cols-2 gap-4">
              {macroNutrients.map((nutrient, index) => {
                const percentage = Math.min((nutrient.current / nutrient.target) * 100, 100);
                const IconComponent = nutrient.icon;
                
                return (
                  <div key={index} className="bg-white border rounded-lg p-4 shadow-sm">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <div className={`p-2 rounded-full ${nutrient.color.replace('bg-', 'bg-').replace('-500', '-100')}`}>
                          <IconComponent className={`h-4 w-4 ${nutrient.color.replace('bg-', 'text-')}`} />
                        </div>
                        <span className="text-sm font-medium text-gray-700">{nutrient.name}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">{nutrient.current}{nutrient.unit}</span>
                        <span className="text-gray-500">/ {nutrient.target}{nutrient.unit}</span>
                      </div>
                      
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${nutrient.color} transition-all duration-300`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      
                      <div className="text-right">
                        <span className={`text-xs font-medium ${
                          percentage >= 90 ? 'text-green-600' : 
                          percentage >= 70 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {percentage.toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-4">
              {[
                { key: 'calories', name: 'Calories', unit: 'kcal', color: 'bg-green-500' },
                { key: 'protein', name: 'Protein', unit: 'g', color: 'bg-orange-500' },
                { key: 'carbs', name: 'Carbs', unit: 'g', color: 'bg-blue-500' },
                { key: 'fats', name: 'Fats', unit: 'g', color: 'bg-yellow-500' }
              ].map((nutrient) => (
                <div key={nutrient.key} className="bg-gray-50 rounded-lg p-4">
                  <Label className="text-sm font-medium text-gray-700 mb-3 block">{nutrient.name}</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">Current ({nutrient.unit})</Label>
                      <Input
                        type="number"
                        value={nutritionForm[nutrient.key as keyof typeof nutritionForm].current}
                        onChange={(e) => handleMacroChange(nutrient.key, 'current', Number(e.target.value))}
                        className="border-green-200"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">Target ({nutrient.unit})</Label>
                      <Input
                        type="number"
                        value={nutritionForm[nutrient.key as keyof typeof nutritionForm].target}
                        onChange={(e) => handleMacroChange(nutrient.key, 'target', Number(e.target.value))}
                        className="border-green-200"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Micro Nutrients Section */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-green-800 flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>Micro Nutrients</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!editingNutrition ? (
            <div className="grid grid-cols-2 gap-4">
              {microNutrients.map((nutrient, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-blue-600">
                        {nutrient.name.charAt(0)}
                      </span>
                    </div>
                    <span className="text-sm font-medium text-gray-700">{nutrient.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-16">
                      <Progress 
                        value={nutrient.value} 
                        className="h-2"
                      />
                    </div>
                    <span className={`text-xs font-medium min-w-[35px] ${
                      nutrient.value >= 80 ? 'text-green-600' : 
                      nutrient.value >= 60 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {nutrient.value}{nutrient.unit}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {[
                { key: 'vitaminA', name: 'Vitamin A' },
                { key: 'vitaminC', name: 'Vitamin C' },
                { key: 'vitaminD', name: 'Vitamin D' },
                { key: 'iron', name: 'Iron' },
                { key: 'calcium', name: 'Calcium' },
                { key: 'zinc', name: 'Zinc' },
                { key: 'magnesium', name: 'Magnesium' },
                { key: 'folate', name: 'Folate' }
              ].map((nutrient) => (
                <div key={nutrient.key} className="space-y-2">
                  <Label className="text-sm font-medium text-gray-700">{nutrient.name}</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={nutritionForm.micronutrients[nutrient.key as keyof typeof nutritionForm.micronutrients]}
                      onChange={(e) => handleMicroChange(nutrient.key, Number(e.target.value))}
                      className="border-green-200"
                    />
                    <span className="text-sm text-gray-500">%</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Ayurvedic Prescription Section */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-green-800 flex items-center space-x-2">
            <Leaf className="h-5 w-5" />
            <span>Today's Ayurvedic Prescription</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!editingNutrition ? (
            <>
              {/* Dosha Balance Note */}
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <Info className="h-4 w-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-800">Constitutional Balance</span>
                </div>
                <p className="text-sm text-amber-700">
                  {patient.ayurvedicPrescription?.doshaBalance || 'Balancing all doshas'}
                </p>
              </div>

              {/* Herbs & Remedies */}
              <div className="space-y-3">
                <h4 className="font-medium text-gray-800 flex items-center space-x-2">
                  <Pill className="h-4 w-4 text-green-600" />
                  <span>Personalized Herbs & Remedies</span>
                </h4>
                
                {patient.ayurvedicPrescription?.herbs.map((herb, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Leaf className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium text-gray-800">{herb.name}</h5>
                      <p className="text-sm text-gray-600">{herb.dosage}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center text-xs text-gray-500 space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>{herb.timing}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Recommendations */}
              <div className="space-y-2">
                <h4 className="font-medium text-gray-800">Additional Recommendations</h4>
                <div className="space-y-2">
                  {patient.ayurvedicPrescription?.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm text-gray-600">
                      <div className="h-1.5 w-1.5 bg-green-500 rounded-full"></div>
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-6">
              {/* Edit Dosha Balance */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-800">Constitutional Balance</Label>
                <Input
                  value={nutritionForm.doshaBalance}
                  onChange={(e) => setNutritionForm(prev => ({ ...prev, doshaBalance: e.target.value }))}
                  placeholder="e.g., Balancing Pitta | Calming Vata"
                  className="border-green-200"
                />
              </div>

              {/* Edit Herbs */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium text-gray-800">Herbs & Remedies</Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={addHerb}
                    className="text-green-600 border-green-200 hover:bg-green-50"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Herb
                  </Button>
                </div>
                
                {nutritionForm.herbs.map((herb, index) => (
                  <div key={index} className="bg-green-50 rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm text-gray-700">Herb #{index + 1}</Label>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeHerb(index)}
                        className="text-red-500 hover:bg-red-50 h-6 w-6 p-0"
                      >
                        ×
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      <div className="space-y-1">
                        <Label className="text-xs text-gray-600">Name</Label>
                        <Input
                          value={herb.name}
                          onChange={(e) => handleHerbChange(index, 'name', e.target.value)}
                          placeholder="e.g., Triphala"
                          className="border-green-200"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-gray-600">Dosage</Label>
                        <Input
                          value={herb.dosage}
                          onChange={(e) => handleHerbChange(index, 'dosage', e.target.value)}
                          placeholder="e.g., 1 tsp"
                          className="border-green-200"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-gray-600">Timing</Label>
                        <Input
                          value={herb.timing}
                          onChange={(e) => handleHerbChange(index, 'timing', e.target.value)}
                          placeholder="e.g., Before bed with warm water"
                          className="border-green-200"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Edit Recommendations */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium text-gray-800">Additional Recommendations</Label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={addRecommendation}
                    className="text-blue-600 border-blue-200 hover:bg-blue-50"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                
                {nutritionForm.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Input
                      value={rec}
                      onChange={(e) => updateRecommendation(index, e.target.value)}
                      placeholder="Enter recommendation"
                      className="border-green-200 flex-1"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeRecommendation(index)}
                      className="text-red-500 hover:bg-red-50 h-8 w-8 p-0"
                    >
                      ×
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Call to Action */}
      <div className="fixed bottom-20 left-4 right-4 z-10">
        {editingNutrition ? (
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              className="flex-1 h-12 bg-white border-gray-300 hover:bg-gray-50"
              onClick={() => setEditingNutrition(false)}
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 h-12 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white shadow-lg"
              onClick={saveNutritionChanges}
            >
              <Save className="h-5 w-5 mr-2" />
              Save Changes
            </Button>
          </div>
        ) : (
          <Button className="w-full h-12 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white shadow-lg">
            <TrendingUp className="h-5 w-5 mr-2" />
            {readOnly ? 'Contact Dietitian' : 'View Full Plan'}
          </Button>
        )}
      </div>
    </div>
  );
}