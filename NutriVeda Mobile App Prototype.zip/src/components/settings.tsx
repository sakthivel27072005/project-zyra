import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { User, Bell, Shield, Smartphone, Globe, CreditCard, Cloud, LogOut, Edit } from 'lucide-react';

export function Settings() {
  const [profile, setProfile] = useState({
    name: 'Dr. Priya Sharma',
    email: 'priya.sharma@ayurveda.com',
    phone: '+91 98765 43210',
    specialization: 'Ayurvedic Nutrition & Panchakarma',
    experience: '8 years',
    location: 'Mumbai, Maharashtra'
  });

  const [notifications, setNotifications] = useState({
    appointments: true,
    clientUpdates: true,
    dietReminders: false,
    systemUpdates: true,
    marketing: false
  });

  const [privacy, setPrivacy] = useState({
    dataSync: true,
    analytics: true,
    locationTracking: false,
    publicProfile: true
  });

  const [preferences, setPreferences] = useState({
    language: 'english',
    timezone: 'asia-kolkata',
    dateFormat: 'dd-mm-yyyy',
    currency: 'inr'
  });

  return (
    <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl text-green-800">Settings</h1>
          <p className="text-green-600">Manage your account and preferences</p>
        </div>
      </div>

      {/* Profile Settings */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <User className="h-5 w-5" />
            <span>Profile & Account</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center space-x-4">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-primary text-white text-xl">PS</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="font-medium">{profile.name}</h3>
              <p className="text-sm text-gray-600">{profile.specialization}</p>
              <Badge variant="outline" className="mt-1">
                Premium Subscriber
              </Badge>
            </div>
            <Button variant="outline" size="sm" className="border-green-200 hover:bg-green-50">
              <Edit className="h-3 w-3 mr-2" />
              Edit Photo
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={profile.name}
                onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                className="border-green-200 focus:border-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={profile.email}
                onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                className="border-green-200 focus:border-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={profile.phone}
                onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                className="border-green-200 focus:border-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="specialization">Specialization</Label>
              <Input
                id="specialization"
                value={profile.specialization}
                onChange={(e) => setProfile(prev => ({ ...prev, specialization: e.target.value }))}
                className="border-green-200 focus:border-primary"
              />
            </div>
          </div>

          <Button className="bg-primary hover:bg-primary/90">
            Save Profile Changes
          </Button>
        </CardContent>
      </Card>

      {/* Subscription & Billing */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <CreditCard className="h-5 w-5" />
            <span>Subscription & Billing</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
            <div>
              <h4 className="font-medium">Premium Plan</h4>
              <p className="text-sm text-gray-600">Unlimited clients & advanced analytics</p>
              <p className="text-xs text-green-600 mt-1">Next billing: Feb 22, 2024</p>
            </div>
            <div className="text-right">
              <p className="text-lg">₹2,999</p>
              <p className="text-xs text-gray-500">/month</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" className="flex-1 border-green-200 hover:bg-green-50">
              Change Plan
            </Button>
            <Button variant="outline" className="flex-1 border-green-200 hover:bg-green-50">
              Billing History
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <Bell className="h-5 w-5" />
            <span>Notifications</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="appointments">Appointment Reminders</Label>
                <p className="text-sm text-gray-600">Get notified about upcoming consultations</p>
              </div>
              <Switch 
                id="appointments"
                checked={notifications.appointments}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, appointments: checked }))}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="client-updates">Client Updates</Label>
                <p className="text-sm text-gray-600">Progress reports and check-ins</p>
              </div>
              <Switch 
                id="client-updates"
                checked={notifications.clientUpdates}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, clientUpdates: checked }))}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="diet-reminders">Diet Plan Reminders</Label>
                <p className="text-sm text-gray-600">Meal and supplement reminders</p>
              </div>
              <Switch 
                id="diet-reminders"
                checked={notifications.dietReminders}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, dietReminders: checked }))}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="system-updates">System Updates</Label>
                <p className="text-sm text-gray-600">App updates and maintenance notices</p>
              </div>
              <Switch 
                id="system-updates"
                checked={notifications.systemUpdates}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, systemUpdates: checked }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Language & Region */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <Globe className="h-5 w-5" />
            <span>Language & Region</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="language">Language</Label>
              <Select value={preferences.language} onValueChange={(value) => setPreferences(prev => ({ ...prev, language: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="english">English</SelectItem>
                  <SelectItem value="hindi">हिन्दी (Hindi)</SelectItem>
                  <SelectItem value="tamil">தமிழ் (Tamil)</SelectItem>
                  <SelectItem value="bengali">বাংলা (Bengali)</SelectItem>
                  <SelectItem value="marathi">मराठी (Marathi)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="timezone">Timezone</Label>
              <Select value={preferences.timezone} onValueChange={(value) => setPreferences(prev => ({ ...prev, timezone: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asia-kolkata">Asia/Kolkata (IST)</SelectItem>
                  <SelectItem value="asia-dubai">Asia/Dubai (GST)</SelectItem>
                  <SelectItem value="america-new_york">America/New York (EST)</SelectItem>
                  <SelectItem value="europe-london">Europe/London (GMT)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date-format">Date Format</Label>
              <Select value={preferences.dateFormat} onValueChange={(value) => setPreferences(prev => ({ ...prev, dateFormat: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dd-mm-yyyy">DD-MM-YYYY</SelectItem>
                  <SelectItem value="mm-dd-yyyy">MM-DD-YYYY</SelectItem>
                  <SelectItem value="yyyy-mm-dd">YYYY-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={preferences.currency} onValueChange={(value) => setPreferences(prev => ({ ...prev, currency: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="inr">₹ Indian Rupee (INR)</SelectItem>
                  <SelectItem value="usd">$ US Dollar (USD)</SelectItem>
                  <SelectItem value="eur">€ Euro (EUR)</SelectItem>
                  <SelectItem value="gbp">£ British Pound (GBP)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Privacy & Security */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-800">
            <Shield className="h-5 w-5" />
            <span>Privacy & Security</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="data-sync">Cloud Data Sync</Label>
                <p className="text-sm text-gray-600">Sync your data across devices</p>
              </div>
              <div className="flex items-center space-x-2">
                <Cloud className="h-4 w-4 text-gray-500" />
                <Switch 
                  id="data-sync"
                  checked={privacy.dataSync}
                  onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, dataSync: checked }))}
                />
              </div>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="analytics">Usage Analytics</Label>
                <p className="text-sm text-gray-600">Help improve the app with anonymous usage data</p>
              </div>
              <Switch 
                id="analytics"
                checked={privacy.analytics}
                onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, analytics: checked }))}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="public-profile">Public Profile</Label>
                <p className="text-sm text-gray-600">Allow clients to find your profile</p>
              </div>
              <Switch 
                id="public-profile"
                checked={privacy.publicProfile}
                onCheckedChange={(checked) => setPrivacy(prev => ({ ...prev, publicProfile: checked }))}
              />
            </div>
          </div>
          <div className="pt-4">
            <Button variant="outline" className="w-full border-green-200 hover:bg-green-50">
              Change Password
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* App Info & Actions */}
      <Card className="shadow-md border-green-100">
        <CardContent className="p-4 space-y-4">
          <div className="text-center space-y-2">
            <h3 className="font-medium text-green-800">NutriVeda</h3>
            <p className="text-sm text-gray-600">Version 2.1.0</p>
            <p className="text-xs text-gray-500">Modern Nutrition with Ancient Wisdom</p>
          </div>
          <div className="space-y-2">
            <Button variant="outline" className="w-full border-green-200 hover:bg-green-50">
              Help & Support
            </Button>
            <Button variant="outline" className="w-full border-green-200 hover:bg-green-50">
              Privacy Policy
            </Button>
            <Button variant="outline" className="w-full border-green-200 hover:bg-green-50">
              Terms of Service
            </Button>
          </div>
          <Separator />
          <Button variant="destructive" className="w-full">
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}