import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Download, TrendingUp, TrendingDown, Minus, Activity, Users, Calendar, Target } from 'lucide-react';

export function ReportsAnalytics() {
  // Sample data for charts
  const doshaBalanceData = [
    { month: 'Oct', vata: 65, pitta: 45, kapha: 70 },
    { month: 'Nov', vata: 70, pitta: 40, kapha: 65 },
    { month: 'Dec', vata: 75, pitta: 35, kapha: 60 },
    { month: 'Jan', vata: 80, pitta: 30, kapha: 55 }
  ];

  const nutrientIntakeData = [
    { day: 'Mon', protein: 85, carbs: 75, fat: 70, target: 80 },
    { day: 'Tue', protein: 90, carbs: 80, fat: 75, target: 80 },
    { day: 'Wed', protein: 80, carbs: 70, fat: 80, target: 80 },
    { day: 'Thu', protein: 95, carbs: 85, fat: 85, target: 80 },
    { day: 'Fri', protein: 88, carbs: 78, fat: 82, target: 80 },
    { day: 'Sat', protein: 92, carbs: 88, fat: 88, target: 80 },
    { day: 'Sun', protein: 85, carbs: 75, fat: 80, target: 80 }
  ];

  const clientProgressData = [
    { name: 'Excellent Progress', value: 12, color: '#4CAF50' },
    { name: 'Good Progress', value: 8, color: '#2196F3' },
    { name: 'Needs Attention', value: 4, color: '#FF9800' }
  ];

  const wellnessMetrics = [
    { label: 'Average Wellness Score', value: '87%', change: '+5%', trend: 'up', icon: Activity },
    { label: 'Client Retention Rate', value: '94%', change: '+2%', trend: 'up', icon: Users },
    { label: 'Diet Plan Adherence', value: '78%', change: '-3%', trend: 'down', icon: Target },
    { label: 'Consultation Completion', value: '96%', change: '0%', trend: 'neutral', icon: Calendar }
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-red-600" />;
      case 'neutral': return <Minus className="h-4 w-4 text-gray-600" />;
      default: return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-green-600';
      case 'down': return 'text-red-600';
      case 'neutral': return 'text-gray-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl text-green-800">Reports & Analytics</h1>
          <p className="text-green-600">Track progress and insights across your practice</p>
        </div>
        <div className="flex items-center space-x-2">
          <Select defaultValue="this-month">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this-week">This Week</SelectItem>
              <SelectItem value="this-month">This Month</SelectItem>
              <SelectItem value="this-quarter">This Quarter</SelectItem>
              <SelectItem value="this-year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button className="bg-primary hover:bg-primary/90">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-4">
        {wellnessMetrics.map((metric, index) => (
          <Card key={index} className="shadow-md border-green-100">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{metric.label}</p>
                  <p className="text-xl">{metric.value}</p>
                  <div className="flex items-center space-x-1 mt-1">
                    {getTrendIcon(metric.trend)}
                    <span className={`text-sm ${getTrendColor(metric.trend)}`}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <div className="p-2 rounded-full bg-green-100">
                  <metric.icon className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Dosha Balance Trends */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Dosha Balance Trends</CardTitle>
          <p className="text-sm text-gray-600">Average client dosha balance over time</p>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={doshaBalanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" stroke="#666" fontSize={12} />
              <YAxis stroke="#666" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #4CAF50', 
                  borderRadius: '8px',
                  fontSize: '12px'
                }} 
              />
              <Line type="monotone" dataKey="vata" stroke="#FF9800" strokeWidth={2} name="Vata" />
              <Line type="monotone" dataKey="pitta" stroke="#F44336" strokeWidth={2} name="Pitta" />
              <Line type="monotone" dataKey="kapha" stroke="#4CAF50" strokeWidth={2} name="Kapha" />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex justify-center space-x-4 mt-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <span className="text-xs">Vata</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span className="text-xs">Pitta</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-xs">Kapha</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Nutrient Intake vs Recommended */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Weekly Nutrient Intake Analysis</CardTitle>
          <p className="text-sm text-gray-600">Average intake vs recommended values (%)</p>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={nutrientIntakeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="day" stroke="#666" fontSize={12} />
              <YAxis stroke="#666" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #4CAF50', 
                  borderRadius: '8px',
                  fontSize: '12px'
                }} 
              />
              <Bar dataKey="protein" fill="#4CAF50" radius={[2, 2, 0, 0]} name="Protein" />
              <Bar dataKey="carbs" fill="#2196F3" radius={[2, 2, 0, 0]} name="Carbs" />
              <Bar dataKey="fat" fill="#FF9800" radius={[2, 2, 0, 0]} name="Fat" />
              <Line type="monotone" dataKey="target" stroke="#666" strokeDasharray="5 5" name="Target" />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex justify-center space-x-4 mt-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-xs">Protein</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-xs">Carbs</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <span className="text-xs">Fat</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Client Progress Distribution */}
      <Card className="shadow-md border-green-100">
        <CardHeader>
          <CardTitle className="text-green-800">Client Progress Distribution</CardTitle>
          <p className="text-sm text-gray-600">Current status of all active clients</p>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <ResponsiveContainer width="60%" height={150}>
              <PieChart>
                <Pie
                  data={clientProgressData}
                  cx="50%"
                  cy="50%"
                  outerRadius={60}
                  fill="#8884d8"
                  dataKey="value"
                  strokeWidth={2}
                  stroke="#fff"
                >
                  {clientProgressData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-3">
              {clientProgressData.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    ></div>
                    <span className="text-sm">{item.name}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {item.value} clients
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Cards */}
      <div className="grid grid-cols-1 gap-4">
        <Card className="shadow-md border-green-100">
          <CardHeader>
            <CardTitle className="text-green-800">Monthly Summary Report</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <Label className="text-gray-600">Total Consultations</Label>
                <p className="text-lg">127</p>
              </div>
              <div>
                <Label className="text-gray-600">New Clients Added</Label>
                <p className="text-lg">8</p>
              </div>
              <div>
                <Label className="text-gray-600">Diet Plans Created</Label>
                <p className="text-lg">23</p>
              </div>
              <div>
                <Label className="text-gray-600">Follow-ups Completed</Label>
                <p className="text-lg">89</p>
              </div>
            </div>
            <div className="pt-4 border-t border-green-100">
              <h4 className="font-medium mb-2">Key Insights</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• 85% of clients show improved digestive health</li>
                <li>• Vata imbalance is the most common concern (45%)</li>
                <li>• Weekend diet adherence needs improvement</li>
                <li>• Client satisfaction score: 4.7/5</li>
              </ul>
            </div>
            <Button variant="outline" className="w-full border-green-200 hover:bg-green-50">
              <Download className="h-4 w-4 mr-2" />
              Download Detailed Report
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}