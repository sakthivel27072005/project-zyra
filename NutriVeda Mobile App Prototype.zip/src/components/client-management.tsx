import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Search, Plus, User, Calendar, Phone, Mail, Activity, TrendingUp } from 'lucide-react';

interface Client {
  id: string;
  name: string;
  age: number;
  gender: string;
  contact: string;
  prakriti: string;
  healthConcerns: string[];
  lastConsultation: string;
  progress: 'excellent' | 'good' | 'needs-attention';
}

export function ClientManagement() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  const clients: Client[] = [
    {
      id: '1',
      name: 'Priya Sharma',
      age: 34,
      gender: 'Female',
      contact: '+91 98765 43210',
      prakriti: 'Pitta-Vata',
      healthConcerns: ['Digestive Issues', 'Stress'],
      lastConsultation: '2024-01-20',
      progress: 'excellent'
    },
    {
      id: '2',
      name: 'Rahul Mehta',
      age: 41,
      gender: 'Male',
      contact: '+91 87654 32109',
      prakriti: 'Kapha-Pitta',
      healthConcerns: ['Weight Management', 'Joint Pain'],
      lastConsultation: '2024-01-18',
      progress: 'good'
    },
    {
      id: '3',
      name: 'Anjali Reddy',
      age: 28,
      gender: 'Female',
      contact: '+91 76543 21098',
      prakriti: 'Vata-Pitta',
      healthConcerns: ['Insomnia', 'Anxiety'],
      lastConsultation: '2024-01-15',
      progress: 'needs-attention'
    }
  ];

  const [newClient, setNewClient] = useState({
    name: '',
    age: '',
    gender: '',
    contact: '',
    prakriti: '',
    healthConcerns: ''
  });

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getProgressColor = (progress: string) => {
    switch (progress) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'needs-attention': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressIcon = (progress: string) => {
    switch (progress) {
      case 'excellent': return <TrendingUp className="h-3 w-3" />;
      case 'good': return <Activity className="h-3 w-3" />;
      case 'needs-attention': return <Activity className="h-3 w-3" />;
      default: return <Activity className="h-3 w-3" />;
    }
  };

  if (selectedClient) {
    return (
      <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => setSelectedClient(null)}>
            ← Back to Clients
          </Button>
        </div>

        <div className="space-y-4">
          <Card className="shadow-md border-green-100">
            <CardHeader>
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-primary text-white text-lg">
                    {selectedClient.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-green-800">{selectedClient.name}</CardTitle>
                  <p className="text-gray-600">{selectedClient.age} years, {selectedClient.gender}</p>
                  <Badge className={`mt-2 ${getProgressColor(selectedClient.progress)}`}>
                    {getProgressIcon(selectedClient.progress)}
                    <span className="ml-1 capitalize">{selectedClient.progress.replace('-', ' ')}</span>
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-gray-600">Contact</Label>
                  <div className="flex items-center space-x-2 mt-1">
                    <Phone className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">{selectedClient.contact}</span>
                  </div>
                </div>
                <div>
                  <Label className="text-sm text-gray-600">Prakriti Type</Label>
                  <p className="text-sm mt-1">{selectedClient.prakriti}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-600">Last Consultation</Label>
                  <div className="flex items-center space-x-2 mt-1">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">{selectedClient.lastConsultation}</span>
                  </div>
                </div>
                <div>
                  <Label className="text-sm text-gray-600">Health Concerns</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedClient.healthConcerns.map((concern, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {concern}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            <Card className="shadow-md border-green-100">
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <p className="text-lg">Weight Progress</p>
                <p className="text-sm text-gray-600">-3.2 kg this month</p>
              </CardContent>
            </Card>
            <Card className="shadow-md border-green-100">
              <CardContent className="p-4 text-center">
                <Activity className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <p className="text-lg">Wellness Score</p>
                <p className="text-sm text-gray-600">85/100</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button className="bg-primary hover:bg-primary/90">
              Schedule Consultation
            </Button>
            <Button variant="outline" className="border-green-200 hover:bg-green-50">
              Update Diet Plan
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6 bg-gradient-to-br from-green-50 to-amber-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl text-green-800">Client Management</h1>
        <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Add Client
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-green-800">Add New Client</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  placeholder="Enter client's full name"
                  value={newClient.name}
                  onChange={(e) => setNewClient(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Age"
                    value={newClient.age}
                    onChange={(e) => setNewClient(prev => ({ ...prev, age: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={newClient.gender} onValueChange={(value) => setNewClient(prev => ({ ...prev, gender: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="contact">Contact Number</Label>
                <Input
                  id="contact"
                  placeholder="+91 XXXXX XXXXX"
                  value={newClient.contact}
                  onChange={(e) => setNewClient(prev => ({ ...prev, contact: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="prakriti">Prakriti Type</Label>
                <Select value={newClient.prakriti} onValueChange={(value) => setNewClient(prev => ({ ...prev, prakriti: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Prakriti" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vata">Vata</SelectItem>
                    <SelectItem value="pitta">Pitta</SelectItem>
                    <SelectItem value="kapha">Kapha</SelectItem>
                    <SelectItem value="vata-pitta">Vata-Pitta</SelectItem>
                    <SelectItem value="pitta-kapha">Pitta-Kapha</SelectItem>
                    <SelectItem value="kapha-vata">Kapha-Vata</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="health-concerns">Health Concerns</Label>
                <Textarea
                  id="health-concerns"
                  placeholder="List main health concerns..."
                  value={newClient.healthConcerns}
                  onChange={(e) => setNewClient(prev => ({ ...prev, healthConcerns: e.target.value }))}
                />
              </div>
              <div className="flex space-x-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => setShowAddForm(false)}
                >
                  Add Client
                </Button>
                <Button variant="outline" onClick={() => setShowAddForm(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search clients..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 border-green-200 focus:border-primary"
        />
      </div>

      {/* Clients List */}
      <div className="space-y-3">
        {filteredClients.map((client) => (
          <Card 
            key={client.id} 
            className="shadow-md border-green-100 cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setSelectedClient(client)}
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="bg-primary text-white">
                    {client.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-green-800">{client.name}</h3>
                    <Badge className={`text-xs ${getProgressColor(client.progress)}`}>
                      {getProgressIcon(client.progress)}
                      <span className="ml-1 capitalize">{client.progress.replace('-', ' ')}</span>
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    {client.age} years • {client.prakriti} • Last seen: {client.lastConsultation}
                  </p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {client.healthConcerns.slice(0, 2).map((concern, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {concern}
                      </Badge>
                    ))}
                    {client.healthConcerns.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{client.healthConcerns.length - 2} more
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}