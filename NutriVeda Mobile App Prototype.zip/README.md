
  # NutriVeda Mobile App Prototype

  This is a code bundle for NutriVeda Mobile App Prototype. The original project is available at https://www.figma.com/design/zz7hsPT2TYgIbV8jZ14AQq/NutriVeda-Mobile-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  